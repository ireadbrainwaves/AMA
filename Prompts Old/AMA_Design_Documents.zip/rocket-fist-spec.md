# Rocket Fist — Signature Tech Spec

## Overview

The Rocket Fist is AMA's mascot move. It's the first tech enhancement every Cyber Gorilla player buys, it's the hero pose on the Steam capsule art, and it's the moment the player understands what the tech system does — it doesn't just buff numbers, it changes how moves work.

---

## Mechanical Spec

**Enhancement name:** Rocket Fist
**Sold by:** RK-7 "Ark"
**Cost:** 200 credits (exactly Fight 1 prize money)
**Tech capacity cost:** 2 points (of 10 total)
**Attaches to:** Arms slot (default Gorilla arms, or any arm-slot mutation)
**Transforms:** Gorilla Punch

### Before Rocket Fist
| Move | Min Cost | Base Dmg | Target | Notes |
|---|---|---|---|---|
| Gorilla Punch | 2 | 2 | Guard | Single-target Guard pressure. Builds Momentum. |

### After Rocket Fist
| Move | Min Cost | Base Dmg | Target | Notes |
|---|---|---|---|---|
| Rocket Punch | 2 | 2 (split) | Guard + Body | Pierce damage. Splits between Guard and Body. Builds Momentum. |

### Damage Split Rules

The total damage from stamina investment is divided between Guard and Body. The split can follow one of these models (pick during playtesting):

**Option A — Even split (simplest)**
- 4 stamina push → 2 Guard damage + 2 Body damage
- 6 stamina push → 3 Guard damage + 3 Body damage
- Odd numbers round in favor of Guard (3 push → 2 Guard + 1 Body)

**Option B — Primary/secondary (more tactical)**
- Majority goes to Guard, minority pierces to Body
- 4 stamina push → 3 Guard + 1 Body
- 6 stamina push → 4 Guard + 2 Body
- Ratio: roughly 2:1 in favor of the primary target

**Option C — Player chooses split (most complex, most interesting)**
- After stamina push, player drags a slider to allocate between Guard and Body
- Full control but adds a decision to every attack
- Probably too complex for the demo — save for full game

**Recommended for demo: Option A (even split).** Easy to understand, easy to display, immediately communicates what "pierce" means. Players see "2 + 2" and instantly get it.

### Strategic Implications

**What Rocket Fist changes for the Gorilla player:**
- Base Gorilla gameplan: break Guard → unlock Primal Rage finisher → kill with finisher
- Rocket Fist gameplan: chip Guard AND Body simultaneously → opponent is taking Body damage before Guard is even broken → finisher becomes overkill or unnecessary if Body gets low enough
- Momentum passive still stacks on consecutive Guard hits — Rocket Fist counts because it still hits Guard
- Opens up an alternative win condition: Body attrition instead of Guard break → finisher

**What Rocket Fist changes for the opponent:**
- Against base Gorilla: protect Guard, Guard is the only thing under threat until it breaks
- Against Rocket Fist Gorilla: Guard AND Body are both ticking down — can't just stack Guard defense
- Forces opponents to respect Body damage earlier in the fight
- Defensive players who turtle behind Guard are suddenly vulnerable

**Natural counterplay:**
- Rocket Fist splits damage, so Guard breaks SLOWER than base Gorilla Punch
- Against high-Guard opponents (Terror Pin Turtle), the split might mean you never actually break Guard — you're doing 1 Body per hit while tickling their massive Guard pool
- Opponents who pressure the Gorilla's Composure force the Gorilla to spend turns on non-Punch moves, wasting the Rocket Fist investment
- The 2 tech capacity cost means the Gorilla has 8 remaining points — a real constraint on later upgrades

---

## Visual Spec

### Sprite change (permanent after purchase)
- Gorilla's right arm (or both arms) changes from organic gorilla fur to metallic plating
- Visible jet housings/vents on the forearm and knuckles
- Subtle idle glow — the jets are powered down but visible
- Color: gunmetal gray with cyan/blue energy highlights (matches Gorilla's signature color palette)

### Attack animation (Rocket Punch)
1. **Windup** (0.2s) — arm pulls back, jet vents open, cyan glow intensifies
2. **Launch** (0.1s) — fist thrusts forward, jet exhaust fires behind the arm
3. **Impact** (0.15s) — shockwave effect on contact, screen shake (subtle)
4. **Exhaust trail** (0.3s) — jet vapor lingers briefly after impact, dissipates

### Key visual rules
- The jet exhaust is ALWAYS mechanical — no magic, no energy beams. Metal and fire.
- Impact effect shows the split visually: Guard damage number pops on the opponent's chest area, Body damage number pops lower/redder
- The metal fist is visible in the idle sprite too — it's a permanent physical change, not just an attack effect

---

## Hero Pose / Mascot Spec

### The image
Cyber Gorilla, three-quarter view, mid-Rocket Punch.

**The fist:** Forward, filling the right third of the frame. Metal knuckles, jet vents open, exhaust trailing behind. This is the focal point. The fist is the biggest single element.

**The body:** Gorilla frame, hunched forward in the punch stance. One arm is the Rocket Fist (metal, mechanical, jets). The other arm shows a harvested mutation — ideally a Squid tentacle or Bee swarm appendage. This tells the story: this fighter has been BUILT.

**The torso:** Visible mutation graft — chitin plating, energy core, or some alien modification. Shows the Frankenstein progression.

**The background:** Arena environment. Dark, neon-lit. Other fighters visible in silhouette in the background/stands. The setting is immediately clear: this is a tournament.

**The exhaust:** Jet trail from the Rocket Fist extends behind the gorilla, creating a dynamic motion line across the image. This is what makes the pose feel kinetic rather than static.

### Silhouette test
With all detail removed, the silhouette reads as: big ape shape, one arm forward (oversized fist), one arm different (tentacle/mutation), chest modified. Three pieces of information from the outline alone:
1. It's a gorilla (species)
2. It's punching with a mechanical fist (combat + tech)
3. Its body has been changed (mutation system)

That's the entire game pitch in one silhouette.

### Usage
- Steam capsule art (main store image)
- Title screen background
- Loading screen
- Marketing materials
- Social media avatar/banner

---

## Starter Tech Framework (Other Species)

Each species gets a signature 200-credit starter tech that transforms their identity move. Design these later, but the framework is:

| Species | Signature move | Starter tech name | Mechanical change | Visual change |
|---|---|---|---|---|
| Cyber Gorilla | Gorilla Punch | **Rocket Fist** | Split pierce (Guard + Body) | Metal arm, jet exhaust |
| Psycho Squid | Mind Spike | *TBD* | *TBD* | *TBD* |
| Bee Swarm | Sting Barrage | *TBD* | *TBD* | *TBD* |
| Terror Pin Turtle | Shell Block | *TBD* | *TBD* | *TBD* |

### Design principles for starter techs
- Costs exactly 200 credits (Fight 1 prize money)
- Costs 2 tech capacity (leaves 8 for the rest of the run)
- Transforms ONE signature move, not the whole kit
- Changes mechanics, not just numbers — the move works DIFFERENTLY after
- Visible on the sprite permanently — you can see who has their starter tech
- Defines the species identity for marketing — each species' starter tech is their "Pikachu's Thunder"

### Ark's sales pitch for each (first shop visit)
Gorilla: "Customer. I see you're running stock fists. Organic. Fragile. I have a Rocket Fist assembly — titanium alloy, dual jet propulsion, rated for impacts up to 4,000 PSI. Two hundred credits. Your opponent won't know what hit them. Literally. The impact is faster than their nerve signals."

Other species: *TBD — same energy, different tech*
