# AMA: Complete System Design — The Pokémon Itch

**Three NPCs. Three economies. One compulsion loop.**

---

## The Hub Triangle

The 2D overworld hub has three NPCs in alcoves, each with a distinct role, personality, and economy. The player walks between them after every fight. The physical act of walking between NPCs is pacing — it gives the player time to think about decisions between screens.

### Commander Vex — Authority

**Role:** Tournament operator. Bracket display. Fight entry. Rules.

**Personality:** Military discipline. Respects results. Doesn't care about your feelings, cares about your win record. Gets gruffer the more you win because he starts taking you seriously.

**Location:** Near the arena doors / bracket display on the north wall.

**Player relationship:** Vex is the quest giver. He doesn't sell anything, doesn't build anything. He tells you who you're fighting and gets out of the way. His respect is earned, not bought.

**Economy:** None. Vex is free. His value is information — the bracket, the opponent preview, the tournament rules.

**Demo dialogue beats:**
- Before Fight 1: "Welcome to the Intergalactic Strongman Tournament, rookie. Pick an arena. Try not to die in the first round — the paperwork is annoying."
- Before Fight 2: "One down. Don't get comfortable. [Next opponent species] has been watching your fight."
- Before Fight 3: "You're still here. That's more than I expected. [Opponent] has two mutations. You should visit the doc."
- Before Fight 4: "Finals. [Opponent] has three grafts and a tech rig. Whatever you've built, I hope it's enough."

---

### Dr. Helix — Biology

**Role:** Mutation harvesting. Biomass grafting. The mad scientist.

**Personality:** Manic enthusiasm. Your body is his art project. Every graft is an experiment. He's genuinely delighted by the work regardless of whether you survive it. Refers to patients as "projects." His medical license has been revoked by three species' medical boards.

**Location:** Back room alcove — the surgery bay. Dim lighting, specimen jars, operating table.

**Player relationship:** Helix is excited about you in a way that's slightly unsettling. He doesn't care if you win — he cares about what you bring him to work with. A pristine opponent body makes him giddy. A mangled one disappoints him. This creates the feedback loop where combat style matters.

**Economy:** Mutations (free, harvested from opponents). No currency cost. The "price" is what you destroyed during the fight.

**How harvest works:**

After each win, the player drags the defeated opponent to Helix. He examines the body and declares what's salvageable. The harvest outcome is determined by HOW the player won:

| Kill method | What's salvageable | What's damaged |
|---|---|---|
| Broke their Guard → Finisher | Arms/torso mutations intact | Head mutations potentially damaged |
| Broke their Composure → Finisher | Head/psychic mutations intact | Torso mutations potentially damaged |
| Body damage attrition (wore them down) | Everything partially damaged | Nothing pristine, but more options |
| Dominant KO (fast, clean win) | Helix gets best picks | Almost everything viable |
| Scrappy narrow win | Limited options | Most of the body is wrecked |

Helix presents 1-3 viable mutations depending on the condition. Player picks one (or none). Each mutation targets a body slot:

**4 Mutation Slots:**
- **Head** — psychic abilities, sensory enhancements, neural modifications
- **Arms** — physical attacks, grappling tools, reach modifications
- **Torso** — defensive abilities, armor plating, regeneration
- **Legs** — mobility, evasion, stance modifications

If the target slot is already occupied, the player must choose: keep what they have (with any tech invested) or replace it (losing the old mutation AND its tech). Helix warns them:

"You've already got Chitin Plating on your torso. I can rip it out and graft the Regeneration Membrane instead, but the plasma coating you bolted onto the chitin? Gone. Your call, project."

**Demo dialogue beats:**
- First harvest: "Oh, you brought me a body! Let me see what's... yes, the [mutation] is intact. Beautiful. Hold still. Actually — don't hold still. I haven't attached the anesthetic node yet."
- Good harvest (clean kill): "You barely touched the [body part]! I can pull three viable grafts off this. Christmas morning for me. Pick your favorite."
- Bad harvest (messy kill): "You... really went to town on this one, didn't you. The [mutation A] is pulp. [Mutation B] is hanging by a thread. I can salvage [one option], maybe. That's it."
- Slot replacement: "That [old mutation] served you well. But it's going in the waste bin if you want this [new mutation]. Along with everything you bolted onto it. No refunds from the mechanic."

---

### [NEW] RK-7 ("Ark") — Technology

**Role:** Cybernetic enhancements. Tech shopping. Upgrades for mutations, base moves, and passives.

**Personality:** Greedy merchant. Everything has a price and he'll tell you exactly what that price is before you've finished asking. Not malicious — just purely transactional. He respects money the way Vex respects winning. Has no loyalty to any fighter, species, or outcome. He'd sell upgrades to your next opponent if they had the credits.

RK-7 is an autonomous construct — no species, no homeworld, no biological needs. He showed up at Axis-9 roughly forty years ago, opened the workshop, and has been selling tech to fighters ever since. Nobody knows who built him. Nobody knows where his inventory comes from. He deflects all questions about his origin with price quotes.

He calls everyone "customer." He's never used a name.

**Location:** Workshop alcove opposite Helix's surgery bay. Workbench, tools, sparks, mounted display showing available upgrades. The aesthetic is a mechanic's garage crossed with a pawn shop — organized chaos with a price tag on everything.

**Player relationship:** Purely transactional. Ark doesn't care about you. He cares about your credits. But he's honest — he won't sell you something useless, because return customers spend more. His recommendations are genuine, motivated entirely by the desire for repeat business.

**Economy:** Credits (prize money from fights). Scaling with fight number:

| Fight | Prize money | Rationale |
|---|---|---|
| Fight 1 | 200 credits | Just enough for one cheap enhancement |
| Fight 2 | 400 credits | Can afford a mid-tier upgrade |
| Fight 3 | 700 credits | Enough for a serious tech investment |
| Fight 4 (finals) | — | No shop after the last fight |

Total possible credits across a run: **1,300**. This is the tech budget for the entire demo. Enhancement prices need to be calibrated so the player can afford 3-5 upgrades total, forcing choices about where to invest.

**Tech Capacity:** Each species has a tech capacity of 10 points. Each enhancement costs tech points. This prevents stacking unlimited upgrades even if you have the money.

**Enhancement catalog (demo scope — 8-10 total):**

OFFENSIVE (make hits harder):
- Plasma Coating (200 credits, 2 tech) — move deals +1 base damage
- Venom Injector (300 credits, 2 tech) — move applies 1 Body damage/turn for 2 turns
- Neural Scrambler (400 credits, 3 tech) — move also chips 1 Composure as secondary effect

DEFENSIVE (survive longer):
- Titanium Reinforcement (200 credits, 2 tech) — mutation in this slot gains +3 effective HP
- Shock Plating (150 credits, 1 tech) — attacker takes 1 Body damage when hitting this body part
- Auto-Repair Nanites (500 credits, 3 tech) — mutation regenerates durability over time

UTILITY (change how things work):
- Quick-Release (150 credits, 1 tech) — reduce a move's stamina cost by 1
- Tracking Software (300 credits, 2 tech) — move gains advantage vs evasion
- Overclock (500 credits, 3 tech) — once per fight, use this move twice in one turn

PASSIVE UPGRADES (enhance species passive):
- Momentum Capacitor (400 credits, 3 tech) — Gorilla: Momentum doesn't reset on loss
- Paranoia Amplifier (400 credits, 3 tech) — Squid: corrupted moves show completely wrong info
- Sting Synthesizer (300 credits, 2 tech) — Bee: Residual Sting deals 2 damage instead of 1
- Tax Collector (300 credits, 2 tech) — Turtle: Stamina Tax triggers on 2+ instead of 3+

**Critical rule: Tech enhancements are attached to specific body parts/mutations. If that mutation is replaced at Helix's table, the tech goes with it.** This is stated clearly to the player before every replacement.

**Demo dialogue beats:**
- First visit: "Customer. Welcome to my workshop. I install cybernetic enhancements. You provide credits. I provide results. Browse the display."
- Browsing: "Plasma Coating. Two hundred credits. Increases damage output by one on the attached move. Compatible with any body part. Interested, or browsing?"
- Can't afford: "That costs four hundred. You have two-fifty. Come back richer. I'll be here."
- After purchase: "Installed. Your [body part] now has [enhancement]. Warranty not included. Warranties cost extra. I don't sell warranties."
- Warning about replacement risk: "Customer. A reminder. If Doctor Helix removes that [mutation], my work goes with it. I don't do refunds. Plan accordingly."
- If player has no mutations yet: "Nothing to enhance. Get something grafted first. Then come see me. I'll be here. I'm always here."

---

## The Post-Fight Loop (Complete)

This is the full sequence after every fight in the demo. Every beat serves the Pokémon compulsion cycle.

### Beat 1 — RESULTS (5 seconds)

Screen shows:
- "VICTORY" + fight stats (damage dealt, damage taken, turns elapsed)
- Kill method indicator (Guard break / Composure break / Attrition / Dominant KO)
- Prize money earned: "[X] CREDITS"

**Pokémon itch function:** Reward confirmation. The player feels good. The money number going up is satisfying even before they spend it.

### Beat 2 — HARVEST (30 seconds - 2 minutes)

Transition to Helix's surgery bay. He examines the body.

Screen shows:
- The defeated opponent's body with mutations highlighted
- Helix's assessment: which mutations are salvageable, which are damaged
- Available mutations laid out with their stats and which slot they'd fill
- Current player body shown alongside with existing mutations/slots visible
- If a slot is occupied: clear warning about replacement cost (lose existing mutation + tech)

Player picks one mutation, or passes.

**Pokémon itch function:** This is the catch. The moment of acquisition. Seeing your character physically change in the graft animation is the evolution moment. Passing on a mutation because you're saving the slot for a better one later is the "I'll catch a better one in the next area" feeling.

### Beat 3 — RETURN TO HUB (player-paced)

Player is back in the 2D overworld. They can now:
- Walk to **Ark's workshop** to spend credits on tech enhancements
- Walk to the **bracket display** to scout the next opponent
- Walk to **Vex** for commentary
- Walk directly to the next arena door

This is the breathing room. The player is in control of pacing. No timer, no pressure. They walk between NPCs and think about their build.

**Pokémon itch function:** This is the "team management" phase. Between every gym, you visit the Pokémon Center, rearrange your team, check the town for items, and look at the map. The hub IS Pokémon's town between routes. The physical act of walking between Helix and Ark and the bracket is the ritual that makes each fight feel like a discrete chapter.

### Beat 4 — TECH SHOP (30 seconds - 2 minutes)

At Ark's workshop. Screen shows:
- Available enhancements (filtered to what's compatible with your current body)
- Your current credits
- Your current tech capacity (X/10 used)
- Your current body map with existing mutations and tech highlighted

Player buys enhancements or leaves.

**Pokémon itch function:** This is the TM/item shop. Spending money on your team feels good. Seeing the tech bolt onto your mutation sprite is the "taught Thunderbolt to Pikachu" moment. The limited budget forces choices — you can't buy everything, so you have to prioritize.

### Beat 5 — SCOUT (15 seconds)

Player walks to the bracket display. Screen shows:
- Next opponent: species, visible mutations, fight number
- Your current build alongside for comparison
- Optional: Vex commentary ("That Gorilla's been watching your fights. He knows your Arms are your weak point.")

**Pokémon itch function:** This is looking at the next gym leader's team in the guidebook. You see the challenge, you see the gap, and you immediately start planning. "I need a Legs mutation to counter their speed" or "My torso tech should handle their Guard pressure." The wanting starts again. Loop resets.

### Beat 6 — ENTER ARENA

Player walks to the next door. Prompt: "Enter arena? [E to enter]"

The player is choosing to start the fight. They feel prepared. They've harvested, teched, scouted. Or they haven't, and they're going in raw because they're confident. Either way — the choice to walk through the door is the commitment.

**Pokémon itch function:** Walking into the gym. You've healed up, checked your team, and now you're stepping through the doors. The transition from 2D hub to 3D fight screen is the visual exclamation point.

---

## The 4-Fight Demo: Mapped to Pokémon's Itch

### Fight 1 — "Route 1"

**Opponent:** Basic species, zero mutations, easy AI.
**Purpose:** Teach the combat system. Moves, stamina, resources, matchups.
**Post-fight:** Player earns 200 credits. Helix harvests one species-natural trait (simple mutation, fills one slot). Player visits Ark — can afford one cheap enhancement (Plasma Coating or Quick-Release). Scout shows Fight 2 opponent with ONE visible mutation.

**The itch:** "That opponent in Fight 2 has a mutation I don't. I want it. And I just got this Plasma Coating on my arm — let's see what it does."

### Fight 2 — "First Gym"

**Opponent:** One mutation (visible from bracket). Moderate AI.
**Purpose:** Player fights against a mutated opponent for the first time. Sees what mutations DO in combat. Learns that how they win affects what Helix can salvage.
**Post-fight:** 400 credits. Helix examines the body — harvest quality depends on kill method. Player gets their second mutation (or upgrades the first slot). Ark has mid-tier enhancements now affordable. Scout shows Fight 3 opponent with TWO mutations.

**The itch:** "That fight was harder. Their mutation gave them an edge I didn't expect. But now I have it. And the Fight 3 opponent has TWO mutations — I need to build smarter. Should I tech up my current mutations or save credits for after Fight 3?"

### Fight 3 — "Mid-Game Gym"

**Opponent:** Two mutations. Hard AI. This is the skill check.
**Purpose:** The player's build is tested. Are their harvest choices and tech investments paying off? The opponent has more mutations than the player (2 vs player's likely 2, but opponent's may be better-synergized).
**Post-fight:** 700 credits — the biggest payday. Helix has the most to salvage (2 opponent mutations). Player might face a replacement decision: their slots are filling up, and the new mutation might be better than what they have but they'd lose the tech. Ark's expensive enhancements (Overclock, Auto-Repair) are now affordable. Scout shows the FINAL opponent with THREE mutations and visible tech.

**The itch:** "The final boss has three mutations AND tech. I have the credits to go all-in at Ark's shop. Do I upgrade what I have or replace my Arms mutation with the one I just harvested? If I replace, I lose 200 credits of tech. But the new mutation might be what I need for the final..."

This is the peak decision moment. The sunk cost tension. The theorycrafting. The player is doing Pokémon team optimization in their head.

### Fight 4 — "Elite Four"

**Opponent:** Three mutations + tech enhancements. Boss AI. The final.
**Purpose:** The culmination. Everything the player built across three fights is tested against the strongest opponent. The player is the underdog (fewer mutations) but has the advantage of having CHOSEN their build. The opponent's build is fixed; the player's is curated.
**Post-fight:** Victory screen. Show the player's final Frankenstein body — the full transformation from base species to cybernetic mutant abomination. This is the payoff shot. The thing they built. The Steam screenshot moment.

**The itch (for replayability):** "What if I'd started as a different species? What if I'd taken the Legs mutation from Fight 2 instead of the Arms? What if I'd saved credits for Overclock instead of Plasma Coating?" The desire to run it again with a different build is the postgame itch.

---

## Economy Balance (Napkin Math)

### Credits flow:
- Total earned: 200 + 400 + 700 = **1,300 credits**
- Cheap enhancements: 150-200 credits (1-2 tech)
- Mid enhancements: 300-400 credits (2-3 tech)
- Expensive enhancements: 500 credits (3 tech)
- Tech capacity: 10 points per species

**Target:** Player can afford 3-5 enhancements across a run. They cannot buy everything. Every purchase is a choice. A player who buys three cheap enhancements has a different build than one who saves for two expensive ones.

### Mutation flow:
- Fight 1: Harvest 1 mutation (1/4 slots filled)
- Fight 2: Harvest 1 mutation (2/4 slots filled)
- Fight 3: Harvest 1 mutation (3/4 slots filled) OR replace an existing one
- Fight 4: Final fight, no harvest after

**Target:** Player enters the final fight with 2-3 mutations (not all 4 slots filled). The empty slot is intentional — it means there's always something they WANTED but couldn't get. That unfulfilled desire drives replayability. "Next run I'll fill all four slots."

### Tech investment risk:
- Average tech investment per mutation by Fight 4: ~300-400 credits
- Replacing a mutation with tech = losing that investment
- This means by Fight 3, the replacement decision costs roughly one full fight's prize money
- That's painful enough to make the player think, not painful enough to make them never swap

---

## Summary: Why This Creates the Pokémon Itch

The itch comes from five psychological triggers firing in sequence:

1. **"I want THAT"** — Seeing opponent mutations on the bracket before you can have them. Desire precedes acquisition.

2. **"How do I GET that"** — Learning that combat style affects harvest quality. The getting has skill expression, not just a menu click.

3. **"What do I DO with it"** — The graft scene + tech shop. Building your Frankenstein. Choosing where to invest. Seeing the visual transformation.

4. **"One more fight"** — Scouting the next opponent and realizing you need one more upgrade to be ready. The perpetual "almost there" feeling.

5. **"What if I'd done it differently"** — Post-run reflection. The desire to run again with different choices. Different species, different harvest order, different tech path.

Pokémon hits all five. Slay the Spire hits all five. Hades hits all five. AMA now has the architecture to hit all five in a 4-fight demo.
