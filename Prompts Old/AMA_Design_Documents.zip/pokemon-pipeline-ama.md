# Pokémon's Production Pipeline → AMA Translation Guide

**How Game Freak builds 800+ creatures, a layered combat system, and a 40-hour progression arc — and what AMA should steal, adapt, or ignore.**

---

## Layer 1: Creature Design Pipeline

### How Game Freak does it

Every Pokémon goes through a fixed pipeline:

**Concept → Silhouette → Type Assignment → Base Stat Total (BST) → Stat Distribution → Ability Design → Movepool Curation → Evolution Gating**

The order matters. They don't start with numbers — they start with identity.

1. **Concept/silhouette first.** Ken Sugimori's rule: every Pokémon must be recognizable from its silhouette alone. This isn't just art direction — it's gameplay communication. In a 3-second team preview, you need to instantly identify what you're facing. Silhouette = role identity.

2. **Type assignment.** Types are the game's primary strategic language. A creature's type tells you its weaknesses, resistances, and STAB (Same Type Attack Bonus) before you know a single stat. Dual typing creates 171 possible type combinations, each with a unique defensive profile. Type is the first "build decision" the game makes for each creature.

3. **Base Stat Total (BST) budget.** Every Pokémon gets a BST that signals its power tier:
   - Route 1 fodder: ~250-300 BST
   - Mid-game pokemon: ~400-450 BST
   - Fully evolved starters: ~530 BST
   - Pseudo-legendaries: 600 BST (exactly, always)
   - Cover legendaries: 670-680 BST
   - The BST is a BUDGET. It constrains the designer. You can't have 130 Attack AND 130 Speed AND 130 HP. You pick what this creature is good at and sacrifice the rest.

4. **Stat distribution within the budget.** This is where identity becomes mechanics. Shuckle has 230 BST in defenses and 10 in Attack/Speed — it's a wall, period. Ninjask has high Speed and nothing else — it's a setup sweeper. The distribution IS the character.

5. **Ability design.** Abilities are the "special rule" layer. Levitate removes Ground weakness. Intimidate cuts opponent's Attack on switch-in. Abilities modify the type/stat foundation without replacing it. They're the spice, not the main dish.

6. **Movepool curation.** This is the deepest balance lever. A Pokémon with 130 Attack but no good physical moves is balanced by omission. Game Freak carefully controls WHICH moves each creature learns — coverage moves (hitting types you're weak to), setup moves (Swords Dance, Dragon Dance), utility (status, hazards), and recovery. The movepool defines what a Pokémon can actually DO with its stats.

7. **Evolution gating.** Creatures get stronger through evolution, which gates power behind level thresholds, item requirements, or trade conditions. This paces the single-player experience — you can't have a pseudo-legendary at level 5.

### What AMA should take from this

Your species (Cyber Gorilla, Psycho Squid, etc.) need the same pipeline:

**Species Identity → Combat Archetype → Base Stats → Mutation Compatibility → Move/Ability Pool**

- **Each species needs a silhouette rule.** In the Pokemon-style battle view, players see a back sprite and a front sprite. You need instant readability even at 64x96 pixel resolution. The gorilla should look massive and grounded. The squid should look alien and fluid.
- **Combat archetype before numbers.** Decide "Cyber Gorilla is a slow heavy hitter with high HP" before you assign any stats. The archetype constrains the stat budget the same way type constrains Pokémon.
- **Mutation compatibility IS your movepool.** Which mutations a species can equip is your equivalent of movepool curation. If the gorilla can equip every mutation, it has no identity. If it can only equip Strength/Armor mutations and not Speed/Psychic ones, it has a defined role that mutations enhance rather than replace.

---

## Layer 2: The Type System as a Balance Framework

### How Pokémon's type chart works

18 types create a rock-paper-scissors web with 324 offensive interactions (super effective, not very effective, immune, neutral). Dual typing multiplies this — a Steel/Fairy type resists 9 types and is immune to 1, but is weak to Fire and Ground.

The genius is that the type chart is **fully deterministic and memorizable**. There's no randomness in whether Fire beats Grass. The skill is in team composition — covering your weaknesses and exploiting opponent weaknesses across a 6-Pokémon team.

Key design properties:
- **No type is universally best.** Dragon was the closest (resists Fire/Water/Grass/Electric) but is weak to Ice, Dragon, and Fairy. Every strength creates a vulnerability.
- **Immunities create hard counters.** Ground is immune to Electric. Normal is immune to Ghost. These force switches and create the prediction game that IS competitive Pokémon.
- **Dual typing creates unique profiles.** Water/Ground (Swampert) has only ONE weakness (Grass, at 4x). This makes it powerful but also uniquely vulnerable to a single type — high risk, high reward.

### What AMA should take from this

You don't need 18 types, but you need a **strength/weakness web** between species or mutation categories:

- If AMA has 7 species, a 7x7 matchup chart (or simplified 3-4 archetype categories) gives players a strategic language for team building and opponent assessment.
- The BJJ tournament ladder means players face sequential opponents. If opponents have visible species/mutation types, the player can plan their mutation harvesting around upcoming matchups — "I need a Psychic mutation to counter the next opponent's Armor build."
- **The overworld hub can teach this.** NPCs can hint at upcoming opponent types. The holographic bracket display shows who you'll fight next. This is exactly how Pokémon gyms work — the gym's aesthetic and trainers telegraph the leader's type before you fight them.

---

## Layer 3: The Damage Formula Architecture

### Pokémon's formula (from the balance doc)

The damage formula layers multiplicative bonuses:

```
Damage = ((2×Level/5 + 2) × Power × Atk/Def) / 50 + 2
         × STAB (1.5x)
         × Type Effectiveness (0.25x to 4x)
         × Weather (1.5x or 0.5x)
         × Item (e.g., Choice Band 1.5x)
         × Critical Hit (1.5x)
         × Random (0.85-1.0)
         × Ability modifiers
         × Other (Burn halves physical, etc.)
```

A max multiplier stack can hit ~9x damage. But the formula is designed so that reaching 9x requires:
- Correct type matchup (requires team building knowledge)
- Weather setup (requires a turn and a team slot)
- Item commitment (Choice Band locks you into one move)
- Ability synergy (requires specific Pokémon selection)

Each multiplier has a COST. That's the balance.

### Anti-OHKO relief valves

The doc highlights four redundant systems that prevent the game from collapsing into "whoever attacks first wins":

1. **Focus Sash** — survive any hit at 1 HP from full health (item slot cost)
2. **Sturdy** — same effect as an innate ability (can't hold another item-equivalent ability)
3. **Disguise** (Mimikyu) — blocks one hit entirely (one specific Pokémon)
4. **Endure** — survive at 1 HP but costs your turn

Each anti-OHKO tool has a different cost structure. Focus Sash uses your item slot. Sturdy uses your ability slot. Endure uses your turn. This means the defense options don't stack for free — choosing one precludes another.

### What AMA should take from this

Your combat math needs the same layered multiplier structure:

- **Base damage from move/attack selection** (equivalent to Power × Atk/Def)
- **Species advantage modifier** (equivalent to type effectiveness — even a simple 1.25x/0.75x matters)
- **Mutation synergy bonus** (equivalent to STAB — if your mutation matches your attack style, bonus damage)
- **Positional/stance modifier** (unique to AMA's BJJ framing — guard position vs. mount vs. standing could multiply certain attacks)
- **Random variance** (Pokémon uses 0.85-1.0, which is enough to create drama without feeling unfair)

And you need at least ONE anti-OHKO valve. If a gorilla with stacked Strength mutations can one-shot everything, the game collapses. Options:
- A "Second Wind" mechanic (survive one lethal hit per fight)
- Mutation armor that absorbs the first X damage
- A "breakaway" move that costs your turn but prevents a KO

---

## Layer 4: Progression and Difficulty Curve

### How Pokémon paces 40 hours

The single-player campaign is a masterclass in progressive disclosure (the balance doc's term):

**Route 1-3:** You have one Pokémon, opponents have one Pokémon. You learn: attacking, type matchups, healing. Decision space: which move to use.

**Gym 1-2:** You have 3-4 Pokémon, opponents have 2-3. You learn: switching, team composition. Decision space: which Pokémon to send out, when to switch.

**Gym 3-5:** Full team of 6. Opponents use items, status moves, setup. You learn: deeper strategy, held items, abilities. Decision space: team building, item assignment, move coverage.

**Gym 6-8:** Opponents have competitive-adjacent teams. Weather, terrain, signature abilities. You're learning meta concepts without knowing it.

**Elite Four + Champion:** Effectively a boss rush that tests everything you've learned. Each E4 member specializes in a type, forcing you to use your full team.

**Post-game:** Battle Tower / competitive. Now you're optimizing EVs, IVs, natures, held items. The full system is revealed.

The key insight: **the combat system is fully present from hour 1, but the complexity is gated by what opponents throw at you.** A new player in Route 1 has the same damage formula as a competitive player — they just don't know it yet.

### What AMA should take from this

Your BJJ tournament ladder IS this progression curve:

- **Fights 1-2:** Opponent has basic species, no mutations. Player learns: attack/defend, the stance system, basic species matchups. Introduce ONE mechanic per fight.
- **Fights 3-4:** Opponent has 1 mutation each. Player learns: mutation harvesting (the finisher mechanic), how mutations change combat. Player now has mutations too.
- **Fights 5-6:** Opponents have 2-3 mutations, use defensive abilities, exploit matchups. Player learns: build planning, mutation synergy, counter-building.
- **Fights 7-8 (finals):** Fully loaded opponents. The player's accumulated mutations are tested against optimized builds. This is your Elite Four equivalent.

**Critical rule from the doc: failed runs should die fast.** If a player's build is doomed by fight 4, the game should let them lose quickly rather than dragging through 4 more unwinnable fights. Give the player clear signals — if their HP is low and they have no healing mutations, the next fight should be decisive one way or another.

---

## Layer 5: The Overworld → Battle Transition

### How Pokémon handles the switch

The overworld and battle screen are two completely different games sharing a world:

- **Overworld:** Exploration, NPC dialogue, item finding, team management. Low-stress, self-paced. The player is in control of when encounters happen (mostly).
- **Battle:** Turn-based combat with full system depth. High-stress, opponent-paced. The player must react.

The TRANSITION between these two states is critical. Pokémon uses:
1. **Visual shift** — screen wipe, camera zoom, distinct battle background
2. **Audio shift** — overworld music → battle music (immediately signals "pay attention")
3. **UI shift** — free movement → menu-based commands
4. **Pacing shift** — self-paced exploration → opponent-driven turns

The contrast between states is what makes each state feel distinct. If the overworld were as intense as battles, players would burn out. If battles were as low-key as the overworld, they'd feel meaningless.

### What AMA already has right

Your 2D hub → 3D fight screen transition is EXACTLY this pattern, and the aesthetic contrast is intentional (you've said so). The 2D dungeon-crawl overworld is the low-stress state. The 3D Pokemon-style battle view is the high-stress state. The visual gap between them IS the transition signal.

What to add:
- **Audio shift.** The hub needs ambient/chill music. The fight screen needs combat music. Even placeholder tracks from Ableton establish the pacing contrast.
- **Pre-fight information.** Before entering an arena door, the player should see: opponent species, visible mutations, win/loss record. This is your "trainer preview" — it lets the player make informed decisions about whether to heal, swap mutations, or adjust strategy before committing.
- **Post-fight debrief.** After a fight, don't dump the player straight back to the hub. Show: damage dealt/taken, mutations harvested, next opponent preview. This is the "results screen" that Pokémon, Slay the Spire, and Hades all use to make each fight feel like a discrete event with consequences.

---

## Layer 6: Meta-Progression and Replayability

### How Pokémon handles long-term engagement

Single-player Pokémon has a fixed progression — you beat the game once. But the competitive layer has infinite replayability through:

- **Team building as expression.** 800+ Pokémon × movesets × items × abilities = effectively infinite team combinations. No two players run the same team.
- **Metagame shifts.** When one strategy dominates, counters rise, which get countered in turn. The meta is a living ecosystem.
- **Tiered play.** Smogon's tier system (Ubers/OU/UU/RU/NU/PU) means every Pokémon is viable SOMEWHERE. A Pokémon that's uncompetitive in OU might dominate in UU. This is brilliant for perceived balance — nothing feels useless.

### What AMA should take from this

Your BJJ tournament ladder is a single run, but replayability comes from:

- **Different species per run.** If you start as a different species each run, the mutation harvesting path changes completely. A gorilla run plays differently from a squid run because different mutations synergize with different base stats.
- **Opponent randomization.** Shuffling which opponents appear in which tournament slots changes the mutation pool available. One run might offer tons of Speed mutations; another might be Armor-heavy.
- **The multiplayer spectating you've planned.** This is your metagame layer. When players can watch other players' fights, dominant strategies become visible, and counter-strategies emerge naturally.

---

## Layer 7: What Pokémon Gets Wrong (and AMA Should Avoid)

Not everything in the Pokémon pipeline is worth copying:

1. **Hidden stats (IVs/EVs).** Pokémon hides critical competitive information behind opaque systems. A casual player has no idea their Pokémon's IVs are bad. This is the opposite of Slay the Spire's transparency philosophy from the doc. AMA should show ALL combat-relevant numbers.

2. **Speed ties and priority moves create coinflips.** When two Pokémon have identical Speed, who goes first is literally random. AMA should have a deterministic tiebreaker.

3. **Over-reliance on prediction.** Competitive Pokémon is largely a prediction game (will they switch? will they use a status move?). This works for PvP but is frustrating against AI. AMA's PvE fights need the Slay the Spire approach — show enemy intent so the player can make informed decisions rather than guessing.

4. **Power creep across generations.** Each new generation's Pokémon tend to be stronger than the last, making older creatures obsolete. AMA's mutation system should avoid this — new mutations should offer different options, not strictly better ones.

5. **The 4-move limit is both brilliant and frustrating.** It forces hard choices (good) but means some Pokémon literally can't use their best stats because they don't have room for the right moves (bad). AMA should find its own constraint — maybe a mutation slot limit of 3-4 — but make sure every slot can be meaningfully filled.

---

## Summary: The Full Pipeline, AMA Edition

| Pokémon Layer | What It Does | AMA Equivalent |
|---|---|---|
| Silhouette/concept | Instant visual identity | Species design in Scenario.gg — readability at 64px |
| Type system | Strategic language for matchups | Species archetype web (Strength/Speed/Psychic/Armor) |
| BST budget | Power tier + role definition | Base stat total per species, constraining builds |
| Stat distribution | Identity through numbers | Species-specific stat spreads (gorilla = HP/Atk, squid = Spd/Special) |
| Abilities | Special rules per creature | Species-specific passive abilities |
| Movepool curation | Controls what a creature CAN do | Mutation compatibility — which species can equip which mutations |
| Evolution gating | Paces power through progression | Tournament ladder position gates mutation count |
| Type chart | Deterministic matchup knowledge | Species/mutation advantage web |
| Damage formula | Layered multipliers with costs | Base damage × archetype bonus × mutation synergy × stance × variance |
| Anti-OHKO valves | Prevents first-strike dominance | Second Wind / armor absorption / breakaway moves |
| Route → gym progression | Progressive disclosure of complexity | Fights 1-2 basic → 3-4 mutations introduced → 5-6 advanced → 7-8 finals |
| Overworld ↔ battle transition | Pacing contrast between states | 2D hub (chill) → 3D fight screen (intense) |
| Hidden stats (IVs/EVs) | ❌ BAD — hide competitive info | Show everything. Slay the Spire transparency model. |
| Speed ties | ❌ BAD — random coinflip | Deterministic tiebreaker |
| Team preview | Pre-fight information | Opponent species + mutations visible before entering arena |

---

## Next Steps

Priority order for implementing this pipeline:

1. **Define the species archetype web.** Which species beats which? Even a simple 3-category system (Power > Technique > Speed > Power) gives the combat strategic language.
2. **Build the stat budget system.** Each species gets a BST. Distribute it to match identity. Gorilla: 70 HP / 80 Atk / 50 Def / 30 Spd. Squid: 40 HP / 50 Atk / 30 Def / 80 Spd.
3. **Define mutation compatibility.** Which species can equip which mutation categories? This is your movepool curation.
4. **Layer the damage formula.** Base × archetype × mutation × stance × variance. Test it with napkin math before coding.
5. **Design the first 3 fights as progressive disclosure.** Fight 1 teaches attacking. Fight 2 teaches defense/switching. Fight 3 introduces mutations.
