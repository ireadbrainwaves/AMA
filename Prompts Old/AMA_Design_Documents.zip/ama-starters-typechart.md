# AMA: Starter Techs & Type Chart

---

## All Four Starter Techs

Each costs 200 credits (Fight 1 prize money), 2 tech capacity (of 10), transforms one signature move. Every species player buys their starter on their first Ark visit. These are the Pikachu's Thunder of AMA — the move that defines each species in marketing and gameplay.

---

### Cyber Gorilla — ROCKET FIST
**Transforms:** Gorilla Punch → Rocket Punch
**Visual:** Organic arm becomes metal plating with jet vents. Exhaust fires on impact.

| | Before | After |
|---|---|---|
| **Move name** | Gorilla Punch | Rocket Punch |
| **Cost** | 2 stamina | 2 stamina |
| **Base damage** | 2 | 2 (split) |
| **Target** | Guard | Guard + Body |
| **Type** | POWER | POWER |
| **Beats/Loses** | Same | Same |

**Mechanic:** Pierce damage. Total stamina investment splits evenly between Guard and Body damage. (4 push → 2 Guard + 2 Body. Odd numbers round to Guard.)

**Strategic shift:** Base Gorilla is pure Guard pressure → finisher. Rocket Fist Gorilla is dual-threat — chipping Body while breaking Guard. Guard breaks slower, but Body is under threat from turn 1. Opens an alternative attrition win condition.

**Counterplay:** Split damage means focused Guard-break takes longer. High-Guard opponents (Turtle) shrug off the Body chip. Opponents who pressure Gorilla's Composure force non-Punch turns, wasting the investment.

**Ark's pitch:** "Customer. I see you're running stock fists. Organic. Fragile. I have a Rocket Fist assembly — titanium alloy, dual jet propulsion, rated for impacts up to 4,000 PSI. Two hundred credits. Your opponent won't know what hit them. Literally. The impact is faster than their nerve signals."

---

### Psycho Squid — SYNAPSE SWAP
**Transforms:** Mind Spike → Synapse Spike
**Visual:** Tentacle tips gain glowing neural fiber implants. On hit, the opponent's sprite briefly glitches — limbs twitch in wrong directions.

| | Before | After |
|---|---|---|
| **Move name** | Mind Spike | Synapse Spike |
| **Cost** | 2 stamina | 2 stamina |
| **Base damage** | 2 | 2 |
| **Target** | Composure | Composure |
| **Type** | PSYCHIC | PSYCHIC |
| **Beats/Loses** | Same | Same |

**Mechanic:** On hit, two of the opponent's moves are randomly selected and their effects are SWAPPED. The opponent sees the original move names on their menu — but selecting Move A executes Move B's effect, and vice versa. The swap is hidden. The opponent doesn't know WHICH moves are swapped.

**Swap rules:**
- Two moves are randomly selected from the opponent's moveset (excluding already-swapped pairs)
- The swap is permanent until the opponent restores Composure above a threshold (e.g., above 5)
- Multiple Synapse Spikes can create multiple swap pairs (with 5 moves, up to 2 pairs can be active)
- If a swapped move triggers an effect that doesn't meet preconditions (e.g., finisher fires without broken resource), the move completely fizzles — wasted turn, wasted stamina
- The Squid player doesn't know which moves were swapped either — it's pure chaos that the Squid is better equipped to exploit because they KNOW swaps are active

**Strategic shift:** Base Squid chips Composure to unlock Psychic Crush finisher. Synapse Swap Squid turns every Composure hit into a sabotage tool. The opponent must now question every move selection — "Is this actually Gorilla Punch or did it get swapped with Iron Grip?" The paranoia is REAL, not just a display glitch.

**Interaction with Paranoia passive:** Paranoia corrupts the DISPLAY (wrong numbers shown). Synapse Swap corrupts the FUNCTION (wrong effect executes). They stack. An opponent fighting a teched Squid sees wrong information AND gets wrong results. Complete information warfare.

**Counterplay:** Restore Composure above the threshold to clear all swaps. Use moves with no preconditions (basic attacks) to minimize fizzle risk. Avoid committing high stamina when you suspect swaps are active — a fizzle on a 5-stamina push is devastating. Defensive/utility moves are safer since their effects are less catastrophic when swapped.

**Fizzle scenarios:**
- Opponent selects Shell Block (defense), but it was swapped with Snap Bite (attack). Snap Bite fires — opponent gets an attack instead of a block. Awkward but functional.
- Opponent selects Gorilla Punch (Guard damage), but it was swapped with Primal Rage (finisher). Primal Rage tries to fire, Guard isn't broken, move fizzles. Wasted turn AND stamina.
- Opponent selects Sting Barrage (1 cost, fast), but it was swapped with Death Cloud (finisher, 4 cost). Death Cloud tries to fire, Composure isn't broken, fizzles. BUT — the opponent only pushed 1 stamina expecting Sting Barrage. The cost mismatch means they underspent for the swapped move but it fizzled anyway. Double punishment.

**Ark's pitch:** "Customer. Synapse Swap implants. Neural fiber upgrades for the tentacle array. When your Mind Spike connects, it rewires two of their motor pathways. Their brain says 'punch,' their body says 'block.' Or vice versa. They won't know which commands are compromised. Two hundred credits. Confusion is my most popular product."

---

### Bee Swarm — HIVE THRUSTERS
**Transforms:** Sting Barrage → Thruster Barrage
**Visual:** Individual bees gain tiny metallic jet packs. Attack animation shows two rapid-fire waves instead of one, with thruster exhaust trails.

| | Before | After |
|---|---|---|
| **Move name** | Sting Barrage | Thruster Barrage |
| **Cost** | 1 stamina | 1 stamina |
| **Base damage** | 2 | 1 + 1 (two hits) |
| **Target** | Body | Body (x2) |
| **Type** | FAST | FAST |
| **Beats/Loses** | Same | Same |

**Mechanic:** Sting Barrage hits twice at half damage each. Total damage is the same, but each hit is a separate instance. This doubles proc triggers — anything that activates "on hit" fires twice.

**What procs twice:**
- Residual Sting passive: already ticks once per turn regardless, BUT if any future mutations or techs add "on-hit" effects, Hive Thrusters doubles them
- Venom effects (if acquired via mutation or later tech): each hit applies poison separately
- Shield/armor break thresholds: two small hits might not trigger a threshold that one big hit would, OR two hits might pop a shield that only blocks one hit
- Any "on-hit" tech enhancements bought later from Ark

**Strategic shift:** Base Bee is already the attrition king — cheapest moves, passive Body damage every turn. Hive Thrusters double down on death by a thousand cuts. The total damage per turn isn't higher, but the hit COUNT is. This matters when interacting with defensive mechanics — a single Shell Block might absorb one hit but not two. Focus Sash-style "survive at 1 HP" effects get hit twice.

**Counterplay:** Multi-hit is weaker against flat damage reduction. If a mutation gives "reduce incoming damage by 1 per hit," Hive Thrusters lose more value than a single big hit would. High-HP opponents (Gorilla) don't care about the split — 2 damage is 2 damage whether it's 1+1 or 2. The Bee's real weakness remains area attacks that counter FAST type.

**Ark's pitch:** "Customer. Hive Thrusters. Miniaturized jet propulsion for each unit in your swarm. Your barrage hits twice instead of once. Same energy expenditure, double the impact frequency. One hundred percent more stings for zero percent more effort. Two hundred credits. I calculated the value proposition myself. You're welcome."

---

### Terror Pin Turtle — SPIKE PLATING
**Transforms:** Shell Block → Spike Shell
**Visual:** Shell surface gains metallic spike protrusions and reinforced plating. On successful block, sparks fly from the spikes and the attacker's sprite recoils.

| | Before | After |
|---|---|---|
| **Move name** | Shell Block | Spike Shell |
| **Cost** | 1 stamina | 1 stamina |
| **Base damage** | 0 | 0 (base) + reflect |
| **Target** | Self (defense) | Self (defense) + attacker |
| **Type** | DEFENSE | DEFENSE |
| **Beats/Loses** | Same | Same |

**Mechanic:** On successful block (Shell Block wins the matchup), reflects Body damage equal to the opponent's stamina push back at them. If the opponent pushed 4 stamina into an attack that gets blocked, they take 4 Body damage.

**Reflect rules:**
- Only triggers on SUCCESSFUL blocks (Spike Shell wins the technique matchup)
- Reflect damage = opponent's stamina push, applied as Body damage to the attacker
- Does NOT trigger if the opponent wins the matchup (grabs and psychic attacks still beat Shell Block)
- The Turtle still takes zero damage from the blocked attack (standard Shell Block behavior)
- Reflect damage is not affected by the attacker's defensive stats — it's direct Body damage

**Strategic shift:** Base Turtle plays Shell Block to survive and stall. Spike Shell Turtle plays Shell Block to KILL. Every block becomes a potential punish. Opponents who push heavy stamina into attacks risk getting destroyed by their own commitment. A 5-stamina Gorilla Punch blocked by Spike Shell deals 5 Body damage back to the Gorilla — that's half their Body bar from one block.

**Interaction with Stamina Tax passive:** Stamina Tax makes big pushes cost extra. Spike Plating makes big pushes dangerous. Together, they create a lose-lose for aggressive opponents: push heavy and risk massive reflect damage, or push light and get taxed on efficiency. The Turtle becomes a fortress that punishes anyone who attacks it.

**Counterplay:** Don't overcommit stamina against a Turtle. Low pushes (2-3 stamina) minimize reflect risk. Use GRAB and PSYCHIC type moves that beat Shell Block — reflects only trigger on successful blocks. Feint with low-cost moves to bait out Shell Block, then hit with a type that beats it. The reflect is powerful but completely predictable — the Turtle WANTS you to attack into Shell Block, so don't.

**The mind game:** The Turtle player picks Spike Shell. The opponent suspects it and picks a grab to counter. But the Turtle predicted the grab and actually picked Snap Bite (fast, beats... wait, Snap Bite loses to evasion). The meta-layer is: does the Turtle block or not? And if they block, can you afford the reflect? This is the Street Fighter shimmy — the Turtle's version of a mix-up.

**Ark's pitch:** "Customer. Spike Plating. Reinforced titanium spikes across the shell exterior with kinetic redistribution channels. When something hits your shell, the impact energy routes through the spikes and into the attacker. The harder they hit, the more it hurts them. Two hundred credits. I call it the 'aggressive patience' package. My favorite contradiction."

---

## The Type Chart

### Design Philosophy

AMA has 4 species. A full Pokémon-style type chart (18 types, 324 interactions) would be absurd. But NO type chart means species choice is purely cosmetic at the matchup level — your passive and moves matter but there's no inherent advantage or disadvantage walking into a fight based on species alone.

The goal: a simple advantage web that creates **matchup awareness** without hard counters. No matchup should be unwinnable. Every matchup should have a clear "this species has to work harder" dynamic.

### The Matchup Web

```
         CYBER GORILLA
        (Power / Guard pressure)
       ↗ strong vs      ↘ weak vs
      /                    \
BEE SWARM ←——————————→ TERROR PIN TURTLE
(Attrition / Body chip)    (Defense / Punishment)
      \                    /
       ↘ weak vs       ↗ strong vs
        PSYCHO SQUID
       (Control / Composure)
```

### The Four Matchup Advantages

**Gorilla beats Squid**
- WHY: Gorilla's high Guard pressure forces the Squid to respond physically. Squid wants time to set up Composure attacks and Synapse Swaps, but Gorilla's Momentum chain builds faster than Squid can corrupt. Raw power overwhelms information warfare.
- MECHANICALLY: Gorilla's Gorilla Punch / Rocket Punch chips Guard fast. Squid's Guard pool is the lowest of all species. By the time Synapse Swap is active, the Gorilla is already threatening Primal Rage.
- ADVANTAGE SIZE: 55-45. Squid CAN win by landing early Mind Spikes and forcing fizzles, but it's uphill.

**Squid beats Turtle**
- WHY: Turtle's entire gameplan is "block and punish." Squid's Mind Spike ignores Guard entirely — it hits Composure, bypassing the shell. Spike Plating reflects physical damage, but psychic attacks don't trigger reflects. The Turtle's fortress is useless against attacks that go through the walls.
- MECHANICALLY: Mind Spike targets Composure, which the Turtle has no way to restore (Fortress Mode restores Guard, not Composure). Synapse Swap makes the Turtle's own Shell Block unreliable — what if it's been swapped with Snap Bite?
- ADVANTAGE SIZE: 60-40. This is the strongest advantage in the chart. Turtle's tools are almost entirely physical, and the Squid fights on a different plane. But the Turtle's raw HP and Stamina Tax still make it durable.

**Turtle beats Bee**
- WHY: Bee's strategy is death by a thousand cuts — cheap fast attacks and Residual Sting ticking away. The Turtle's Shell Block / Spike Shell absorbs those small hits and reflects them back. Hive Thrusters hit twice, which means two reflect triggers if the Turtle blocks. The Bee is literally killing itself attacking the Turtle.
- MECHANICALLY: Bee's Sting Barrage is FAST type. Shell Block beats FAST. Every time the Bee does what it wants to do (cheap fast attacks), the Turtle counters it. And Spike Plating reflects even small pushes — a 2-stamina Thruster Barrage blocked by Spike Shell still deals 2 Body back to the Bee. Residual Sting's 1 damage/turn barely matters against the Turtle's high HP pool.
- ADVANTAGE SIZE: 60-40. The Bee CAN win by using Swarm Pressure (AREA type, beats evasion, doesn't lose to defense) and Pollen Blind to disrupt, but the Bee's primary tools are the Turtle's favorite food.

**Bee beats Gorilla**
- WHY: Gorilla wants to build Momentum through consecutive Guard hits. The Bee refuses to engage on those terms. Scatter dodges everything, Residual Sting chips Body every turn regardless, and the Bee's cheap moves mean it always has stamina to evade. The Gorilla is swinging at air while slowly bleeding out.
- MECHANICALLY: Gorilla Punch is POWER type. Sting Barrage (FAST) beats POWER. Scatter (EVASION) dodges POWER. The Gorilla's big expensive attacks keep getting countered by the Bee's cheap fast options. Momentum chain keeps getting broken because the Gorilla can't land consecutive Guard hits against a target that won't stand still.
- ADVANTAGE SIZE: 55-45. Gorilla CAN win by landing Iron Grip (GRAB beats EVASION) to pin the Bee down, or by using Ground Pound (AREA) to catch scattered bees. But the Gorilla has to spend more stamina than the Bee every turn, and Residual Sting is always ticking.

### Matchup Summary Table

| Attacker → | Gorilla | Squid | Bee | Turtle |
|---|---|---|---|---|
| **Gorilla** | Mirror | **55-45 W** | 45-55 L | 50-50 |
| **Squid** | 45-55 L | Mirror | 50-50 | **60-40 W** |
| **Bee** | **55-45 W** | 50-50 | Mirror | 40-60 L |
| **Turtle** | 50-50 | 40-60 L | **60-40 W** | Mirror |

### Key Properties of This Chart

**Circular dominance.** Gorilla → Squid → Turtle → Bee → Gorilla. No species is universally best. This is Rock-Paper-Scissors with a fourth element, creating a clean cycle.

**Two neutral matchups.** Gorilla vs Turtle and Squid vs Bee are 50-50. These are the "off-axis" matchups where neither species has a natural advantage. Wins come from player skill, build quality, and adaptation rather than matchup luck.

**No hard counters.** The worst matchup is 60-40 (Squid vs Turtle, Turtle vs Bee). A 60-40 means the disadvantaged player loses 6 out of 10 games at equal skill. That's noticeable but absolutely winnable. For reference, David Sirlin's Yomi (from the balance doc) considers anything worse than 7-3 unacceptable. AMA is well within that range.

**Advantage is mechanical, not numerical.** The Gorilla doesn't deal more damage to the Squid. The advantage comes from how their kits interact — Gorilla's pressure style naturally counters Squid's setup style. This means mutations and tech can flip matchups. A Squid who harvested Gorilla arms might shore up their physical weakness. A Turtle with a Bee's Residual Sting passive (via mutation) can add attrition to their defense.

### How the Bracket Creates Matchup Tension

The player sees all four opponents on the bracket before fighting any of them. Species are visible. This means:

- A Gorilla player sees a Squid (easy), a Bee (hard), a Turtle (neutral), and the final boss.
- The player chooses fight ORDER. Do they fight the easy matchup first to build confidence and earn a safe mutation? Or fight the hard matchup first while both fighters are un-mutated and the advantage is smallest?
- Mutations harvested from early wins can specifically counter later matchup disadvantages. Beat the Squid first, harvest a Composure-restoration mutation, and now the Bee (your hard matchup) is more manageable.

This is EXACTLY how Pokémon route planning works — you check which gym types are coming and adjust your team. AMA does it through bracket order and harvest planning.

### How Mutations Flip Matchups

The type advantage is based on BASE species kits. Mutations change the equation:

**Example: Gorilla vs Bee (normally 45-55 Bee favored)**
- Gorilla harvests a Turtle's Shell Block from a previous fight → now has a DEFENSE option that beats the Bee's FAST attacks
- Matchup shifts toward 50-50 or even Gorilla-favored because the Bee's primary tools are now countered

**Example: Turtle vs Squid (normally 40-60 Squid favored)**
- Turtle harvests a Gorilla's Iron Grip → now has a GRAB that can pressure the Squid physically
- Turtle adds a Composure-restoration mutation → can cleanse Synapse Swap effects
- Matchup shifts toward 50-50 because the Turtle patched its key vulnerability

**This is the meta-progression loop.** The type chart creates the DESIRE to harvest specific mutations. The player sees their bad matchup on the bracket, identifies WHAT they need to counter it, and hunts for that specific mutation in earlier fights. The type chart isn't just balance — it's motivation.

---

## How Matchup Advantages Are Communicated to the Player

### In the hub
- The bracket display shows opponent species with a colored indicator:
  - Green arrow: you have advantage against this species
  - Red arrow: this species has advantage against you  
  - Yellow dash: neutral matchup
- Vex commentary: "That Bee's going to run circles around you. Gorillas have never been great against swarms. Find something to pin them down."

### In the fight
- Pre-fight scouting screen shows the matchup spread
- Move descriptions already say what they beat/lose to (FAST beats POWER, etc.)
- The advantage plays out through mechanics, not hidden modifiers — the player FEELS the disadvantage through their moves being countered more often, not through secret damage reduction

### Teaching the chart
- Fight 1 should ideally be a neutral or favorable matchup so the player wins
- Fight 2 can introduce a slight disadvantage to teach "some matchups are harder"
- By Fight 3, the player understands the web and is actively planning harvests around it
- The type chart is never shown as a chart — it's learned through play, NPC hints, and experience

---

## Complete Starter Tech Summary

| Species | Tech Name | Cost | Transforms | Mechanic | Identity |
|---|---|---|---|---|---|
| Cyber Gorilla | Rocket Fist | 200cr / 2tp | Gorilla Punch → Rocket Punch | Split pierce: Guard + Body | "I hit everything at once" |
| Psycho Squid | Synapse Swap | 200cr / 2tp | Mind Spike → Synapse Spike | Swaps effects of 2 random opponent moves. Permanent until Composure restored. Fizzle on failed preconditions. | "Your body betrays you" |
| Bee Swarm | Hive Thrusters | 200cr / 2tp | Sting Barrage → Thruster Barrage | Hits twice at half damage. Doubles proc triggers. | "Death by two thousand cuts" |
| Terror Pin | Spike Plating | 200cr / 2tp | Shell Block → Spike Shell | Reflects Body damage = opponent's stamina push on successful block | "Hit me. I dare you." |

### The Mascot Lineup (Marketing / Steam Art)

Each species in their starter-tech hero pose:

- **Gorilla:** Metal fist forward, jet exhaust trailing, mid-Rocket Punch. THE primary mascot.
- **Squid:** Tentacles with glowing neural fibers, opponent glitching in the background. The villain energy.
- **Bee:** Swarm with tiny jet packs, motion blur, double-strike trails. The speed demon.
- **Turtle:** Shell covered in metal spikes, attacker bouncing off, sparks flying. The immovable object.

Together, these four images ARE the Steam store page.
