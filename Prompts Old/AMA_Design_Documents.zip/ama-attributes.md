# AMA: Attribute System — Species Stats & Mutation Modifiers

**Four attributes. Fixed budgets. Mutations shift the balance.**

---

## Overview

Every species has four combat attributes that modify how damage is dealt, received, and resisted. These are SEPARATE from the four resources (Guard, Composure, Body, Stamina) — resources are health pools that drain during fights, attributes are permanent modifiers that define HOW those resources drain.

Resources = what you're losing.
Attributes = how fast you lose it.

---

## The Four Attributes

| Attribute | What It Does | Combat Math Impact | Fantasy |
|---|---|---|---|
| **Attack** | Multiplies all outgoing damage | Damage dealt = base × stamina × (Attack / 50) | How hard you hit |
| **Defense** | Reduces incoming physical damage (POWER, FAST, GRAB, AREA) | Physical damage taken = raw damage × (50 / Defense) | How much your body absorbs |
| **Willpower** | Reduces incoming Composure damage (PSYCHIC) + resists mental effects | Psychic damage taken = raw damage × (50 / Willpower). Synapse Swap duration reduced at high Willpower. | Your mental armor |
| **Toughness** | Adds bonus HP to all equipped mutations | Each mutation gains +(Toughness / 10) bonus HP, rounded down | How hard it is to rip your parts off |

### How the Math Works

The baseline is 50 in every attribute. At 50, the multiplier is 1.0x — no bonus, no penalty. Above 50 is a bonus. Below 50 is a penalty.

**Attack example:**
- Gorilla (Attack 75): damage × (75/50) = damage × 1.5x. Every hit deals 50% more.
- Squid (Attack 35): damage × (35/50) = damage × 0.7x. Every hit deals 30% less.
- A Gorilla Rocket Punch at 4 stamina push: base 2 × 4 stamina × 1.5 Attack = 12 total (split 6 Guard + 6 Body). Against a base species with 20 Guard, that's nearly a third of their Guard in one hit.
- A Squid Mind Spike at 4 stamina push: base 2 × 4 stamina × 0.7 Attack = 5.6 → 5 Composure damage. Lower raw damage, but Composure pools are smaller and the Squid's kit has other ways to win.

**Defense example:**
- Turtle (Defense 75): physical damage × (50/75) = damage × 0.67x. Reduces physical hits by a third.
- Bee (Defense 25): physical damage × (50/25) = damage × 2.0x. Takes DOUBLE physical damage. The Bee cannot stand and trade hits.
- A Gorilla Punch dealing 12 raw damage vs Turtle: 12 × 0.67 = 8. The shell eats 4 damage just by existing.
- Same punch vs Bee: 12 × 2.0 = 24. The Bee is in serious trouble if it doesn't dodge.

**Willpower example:**
- Squid (Willpower 80): psychic damage × (50/80) = damage × 0.625x. Nearly 40% psychic resistance.
- Turtle (Willpower 20): psychic damage × (50/20) = damage × 2.5x. Mind Spike hits TWO AND A HALF TIMES harder against a Turtle. This is WHY Squid beats Turtle 60-40.
- Gorilla (Willpower 25): psychic damage × (50/25) = damage × 2.0x. Synapse Swap's mental corruption hits hard because the Gorilla's mind has no defenses.

**Toughness example:**
- Turtle (Toughness 75): each mutation gains +7 HP (75/10 = 7.5, rounded down). A large mutation goes from 12 HP to 19 HP. With Titanium Reinforcement tech (+5), that's 24 HP. Nearly unkillable without exploiting GRAB weakness.
- Squid (Toughness 55): each mutation gains +5 HP. Respectable — the Squid's mental focus somehow holds its grafts together.
- Bee (Toughness 60): each mutation gains +6 HP. The swarm distributes damage across nodes, making individual parts harder to destroy.
- Gorilla (Toughness 50): each mutation gains +5 HP. Average durability. The Gorilla's mutations are strong but not resilient.

---

## Species Base Stats

Every species has a **Base Stat Total (BST) of 200**. The budget forces real tradeoffs — high Attack means low Defense or Willpower. The distribution IS the character identity.

| Species | Attack | Defense | Willpower | Toughness | BST | Role |
|---|---|---|---|---|---|---|
| **Cyber Gorilla** | 75 | 50 | 25 | 50 | 200 | Heavy hitter. Glass mind. |
| **Psycho Squid** | 35 | 30 | 80 | 55 | 200 | Mentalist. Physically fragile. |
| **Bee Swarm** | 60 | 25 | 55 | 60 | 200 | Attrition. Can't take a hit. |
| **Terror Pin Turtle** | 30 | 75 | 20 | 75 | 200 | Fortress. Zero mental game. |

### What the Spreads Mean in Practice

**Cyber Gorilla (75 / 50 / 25 / 50)**
- 75 Attack means every Gorilla Punch hits 50% harder than baseline. Rocket Punch's split pierce becomes devastating — even the Body chip is meaningful at 1.5x.
- 25 Willpower means Psychic attacks deal DOUBLE damage to the Gorilla's Composure. One Synapse Spike from a teched Squid can scramble the Gorilla's moves for the whole fight if Composure isn't restored quickly.
- 50 Defense and Toughness are average — the Gorilla isn't fragile physically, just mentally.
- **Gorilla's strategic identity:** End the fight fast. Every turn you spend NOT hitting is a turn the Squid is dismantling your mind. Momentum isn't just a passive — it's a survival strategy.

**Psycho Squid (35 / 30 / 80 / 55)**
- 35 Attack means raw physical damage is the lowest in the game. Tentacle Lash and Mind Spike deal 30% less than baseline. The Squid doesn't win through damage — it wins through disruption and Composure breaks.
- 30 Defense means physical attacks are amplified by ~67%. A Gorilla Punch hits the Squid like a freight train. Two clean Gorilla Punches can strip the Squid's Guard entirely.
- 80 Willpower makes the Squid nearly immune to psychic attacks and mental effects. Synapse Swap from another Squid is dramatically less effective. Composure attacks bounce off.
- 55 Toughness gives mutations +5 HP — not great, but not paper. The Squid's grafts survive long enough to matter.
- **Squid's strategic identity:** Don't get hit. Use Ink Cloud, Neural Bind, and information advantages to avoid physical exchanges. One Gorilla Punch can unravel the plan. But if the Squid controls the fight mentally, the opponent destroys themselves.

**Bee Swarm (60 / 25 / 55 / 60)**
- 60 Attack is above average — the Bee's constant chip damage is meaningful. Residual Sting + Hive Thrusters at 1.2x adds up relentlessly.
- 25 Defense is the joint-lowest with Squid. The Bee takes massive physical damage. If a Gorilla catches the Bee with Iron Grip, it's catastrophic.
- 55 Willpower gives decent mental resistance — the Bee's collective consciousness is hard to scramble. Synapse Swap is less effective because the swarm distributes decision-making.
- 60 Toughness gives mutations +6 HP — slightly above average. The swarm's distributed body makes individual mutations harder to pick off.
- **Bee's strategic identity:** Never be where the attack lands. Scatter dodges, cheap moves, constant pressure. The Bee's 1-stamina moves mean it always has gas to evade. But if something connects — especially AREA attacks that catch the whole swarm — the Bee crumbles.

**Terror Pin Turtle (30 / 75 / 20 / 75)**
- 30 Attack is just above the Squid's — the Turtle isn't a damage dealer. Spike Shell reflect is the primary damage source, and reflect isn't modified by Attack (it uses the opponent's stamina push).
- 75 Defense reduces physical damage by a third. Shell Block + 75 Defense means physical attacks barely scratch the Turtle. A Gorilla Punch that would deal 12 to a baseline species deals 8 to the Turtle.
- 20 Willpower is the absolute lowest. Psychic attacks deal 2.5x damage. Mind Spike SHREDS the Turtle's Composure. This is the type chart weakness made mathematical — the Squid doesn't just have the right moves, the Turtle literally has no mental armor.
- 75 Toughness gives mutations +7 HP — the highest in the game. Turtle grafts are the hardest to destroy. A Turtle with a teched torso mutation has 24+ HP of armor on it.
- **Turtle's strategic identity:** Let them attack. Spike Shell punishes overcommit. Stamina Tax drains their gas. But NEVER fight a Squid on mental terms. The Turtle has to win before Composure breaks, or it's done.

---

## How Mutations Modify Attributes

Mutations from harvested species apply percentage modifiers to the player's base attributes. These stack with the base stats and with each other.

### Mutation Attribute Modifiers

| Mutation Origin | Attack | Defense | Willpower | Toughness | Net Modifier |
|---|---|---|---|---|---|
| **Gorilla graft** | +15% | — | -5% | — | +10% total. More power, weaker mind. |
| **Squid graft** | — | -5% | +15% | — | +10% total. Stronger mind, softer body. |
| **Bee graft** | +10% | -10% | — | +10% | +10% total. Faster, fragile, durable swarm nodes. |
| **Turtle graft** | -5% | +15% | — | — | +10% total. Tankier, less explosive. |
| **Echomorph graft** | +10% to lowest | — | — | — | +10% total. Shores up your weakness. |
| **Hydravine graft** | — | +5% | — | +10% | +15% total. Premium defensive loot. |
| **Parasitex graft** | +10% | — | +10% | — | +20% total. Best stat loot in the game. |

### Modifier Stacking Example

**Turtle player who harvested Gorilla arms and Hydravine torso:**

| Attribute | Base | + Gorilla Arms (+15% Atk, -5% Will) | + Hydravine Torso (+5% Def, +10% Tough) | Final |
|---|---|---|---|---|
| Attack | 30 | 30 × 1.15 = 34.5 → 34 | No change | **34** |
| Defense | 75 | No change | 75 × 1.05 = 78.75 → 78 | **78** |
| Willpower | 20 | 20 × 0.95 = 19 | No change | **19** |
| Toughness | 75 | No change | 75 × 1.10 = 82.5 → 82 | **82** |

This Turtle traded a sliver of Willpower (20 → 19, already terrible) for meaningfully higher Attack (30 → 34) and significant Toughness (75 → 82, mutations gain +8 HP each). Smart build — shoring up the Turtle's weak offense without sacrificing what it's already good at. The Willpower loss barely matters because it was already the Turtle's dump stat.

**Squid player who harvested Gorilla arms and Turtle torso:**

| Attribute | Base | + Gorilla Arms (+15% Atk, -5% Will) | + Turtle Torso (+15% Def, -5% Atk) | Final |
|---|---|---|---|---|
| Attack | 35 | 35 × 1.15 = 40.25 → 40 | 40 × 0.95 = 38 | **38** |
| Defense | 30 | No change | 30 × 1.15 = 34.5 → 34 | **34** |
| Willpower | 80 | 80 × 0.95 = 76 | No change | **76** |
| Toughness | 55 | No change | No change | **55** |

This Squid got slightly more physical — Attack went from 35 to 38, Defense from 30 to 34. Not huge, but enough to make Tentacle Lash actually threaten. The Willpower drop (80 → 76) is affordable — still the highest in the game. This is a Squid that can trade physical blows AND fight the mental war. A generalist build that patches its biggest weakness.

---

## How Attributes Interact with Existing Systems

### Starter Techs
- **Rocket Fist** (Gorilla): Pierce damage split is calculated AFTER the Attack multiplier. A 75-Attack Gorilla's Rocket Punch at 4 stamina = base 2 × 4 × 1.5 = 12 total → 6 Guard + 6 Body. Devastating early.
- **Synapse Swap** (Squid): Duration before cleanse is extended by the Squid's Willpower advantage. High Willpower Squid = longer swap duration. Low Willpower target = harder to cleanse.
- **Hive Thrusters** (Bee): Each hit is calculated separately with the Attack multiplier. Two hits at 1.2x each doesn't change the total but proc triggers benefit from the higher base.
- **Spike Shell** (Turtle): Reflect damage is NOT modified by Attack — it uses the opponent's stamina push as the damage value. The Turtle's low Attack doesn't matter for reflects. This is WHY Spike Shell is the Turtle's primary damage tool.

### Type Chart Reinforcement
The attributes EXPLAIN the type chart matchups through numbers:
- Gorilla beats Squid: 75 Attack vs 30 Defense = 2.5x damage differential. The Gorilla two-shots the Squid's Guard.
- Squid beats Turtle: 80 Willpower means Squid resists the (few) mental attacks. And Turtle's 20 Willpower means Mind Spike deals 2.5x damage. The numbers make the matchup brutal.
- Turtle beats Bee: 75 Defense reduces the Bee's chip to almost nothing. 75 Toughness means Turtle mutations have +7 HP — the Bee can't destroy them.
- Bee beats Gorilla: 60 Attack with constant hits (1-cost moves, Residual Sting) adds up. Gorilla's 50 Defense doesn't reduce chip enough when it's hitting every single turn.

### Scouting Screen
The player's OWN attributes are shown as exact numbers on:
- Character select screen (bar chart with numbers)
- Body map in the hub (updated after mutations)
- Pre-fight HUD (small stat display)

The OPPONENT's attributes are shown as vague descriptors on the scouting screen:
- "Attack: DEVASTATING" (70+)
- "Attack: STRONG" (55-69)
- "Attack: AVERAGE" (40-54)
- "Attack: WEAK" (25-39)
- "Attack: PATHETIC" (below 25)

Same descriptors for all four attributes. The player sees "Defense: DEVASTATING, Willpower: PATHETIC" on the Turtle and immediately knows: don't punch the shell, attack the mind.

Vex provides commentary that reinforces the scouting data:
- "That Turtle's shell is nearly impenetrable. But between you and me, I've never seen one resist a Psychic attack."
- "The Gorilla hits harder than anything in this bracket. Don't stand in front of it."
- "The Bee's body is fragile. One clean hit and it's in trouble. Problem is landing that hit."

---

## Boss Attribute Spreads

Bosses have elevated BSTs to reflect their mini-boss / final boss status.

| Boss | Attack | Defense | Willpower | Toughness | BST | Notes |
|---|---|---|---|---|---|---|
| **Echomorph** | 50 | 55 | 55 | 60 | 220 | Balanced. No extreme strengths, no weaknesses. Adapts to you instead of overpowering you. |
| **Hydravine** | 45 | 60 | 40 | 75 | 220 | Tanky with massive Toughness. Mutations regen on top of high base HP. Low Willpower — mental attacks cut through. |
| **Parasitex** | 60 | 55 | 50 | 55 | 220 | Above average everywhere. No dump stat. It doesn't need one — it steals YOUR strengths. The stolen mutations shift its stats further with their modifiers. |

The Parasitex's stat spread is deliberately mediocre-plus. It's strong because of what it TAKES from you, not because of its base stats. A Parasitex that steals a Gorilla graft gets +15% Attack (60 → 69). Now it hits almost as hard as the Gorilla itself. That's the horror — it becomes a better version of you using your own parts.

---

## Summary: The Attribute Loop

1. **Character select:** See four species with four stat bars. Pick your playstyle.
2. **Fight:** Your Attack, Defense, Willpower, and Toughness determine how every exchange resolves. High Attack Gorilla deals massive burst. High Defense Turtle shrugs off physical hits.
3. **Harvest:** The mutation you take shifts your attributes. Gorilla arms make you hit harder but think softer. Turtle torso makes you tank but deal less.
4. **Scout:** See the next opponent's attributes as descriptors. "DEVASTATING Defense, PATHETIC Willpower." Plan your approach.
5. **Build:** Choose mutations and tech that shore up weaknesses or double down on strengths. A Gorilla who harvests Squid tentacles gains Willpower but loses Defense — patching the mental weakness at the cost of physical resilience.
6. **Fight again:** Your modified attributes change every combat calculation. The Gorilla who harvested Squid parts now takes 15% less psychic damage. The Synapse Swap that would have destroyed them last fight is manageable now.

Attributes don't add complexity to the turn-by-turn combat — the player never thinks about them mid-fight. They add depth to the BUILD decisions between fights. "Should I harvest the Gorilla arms for +15% Attack or the Turtle torso for +15% Defense?" That's the stat optimization itch. That's the Pokémon EV training loop, compressed into 4 fights instead of 40 hours.
