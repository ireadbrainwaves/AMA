# AMA: Boss Design — Echomorph, Hydravine, Parasitex

**Three bosses. Two slots. One final fight you can never avoid.**

---

## Boss Structure in the Demo

| Fight | Opponent | Role |
|---|---|---|
| Fight 1 | Standard species (random) | Tutorial / warmup |
| Fight 2 | Standard species (random) | Build your Frankenstein |
| Fight 3 | **Echomorph OR Hydravine** (random) | Mini-boss: rules change |
| Fight 4 | **PARASITEX** (always) | Final boss: the mutation thief |

- Player can see the Fight 3 boss on the bracket from the start — species, visible mutations, and a WARNING indicator
- Fight 3 is harvestable — boss mutations are the best loot in the game, and you walk into the Parasitex fight with them
- Parasitex is ALWAYS the final boss. Every build, every run, the player knows what's waiting. The entire run is preparation for this fight.

---

## Standard Species Stat Baseline (for reference)

| Stat | Standard | Mini-Boss (Fight 3) | Final Boss (Fight 4) |
|---|---|---|---|
| Guard | 20 | 25 | 30 |
| Composure | 20 | 25 | 25 |
| Body | 25 | 30 | 35 |
| Stamina | 10 | 12 | 12 |
| Stamina Regen | +3 | +3 | +4 |

Bosses are DURABLE, not damage-inflated. They don't one-shot you — they outlast you. The difficulty comes from their unique mechanics extending the fight into territory where your resources run thin. This follows the balance doc principle: difficulty through systemic modifiers, not stat inflation.

---

## BOSS 1: ECHOMORPH — "The Mirror"

*"It's learning. Stop repeating yourself."*

### Species Identity

The Echomorph is a shapeshifting organism with no fixed anatomy. Its body is a semi-translucent membrane that restructures itself in real-time based on external stimuli. It has no natural fighting style — it copies yours. When it first enters the arena, it's a featureless humanoid silhouette. By turn 5, it looks like a distorted copy of YOU.

### Visual Design

- **Idle:** Smooth, featureless humanoid. Semi-transparent body with a mercury/liquid-metal sheen. No face — just a smooth ovoid head. Faint glow at its center (its core).
- **As it copies:** Your moves appear on its body as echoes. If you used Gorilla Punch, its arm thickens into a gorilla-like shape. If you used Sting Barrage, small insectoid shapes ripple across its surface. By late fight, it's a warped reflection of your character — same mutations, same general silhouette, but wrong. Uncanny valley.
- **Color palette:** Silver-white base, with your species' signature color bleeding in as it copies more. A Gorilla's Echomorph turns steel-blue. A Squid's turns purple-green.

### Passive: ECHO

Every turn after Turn 1, the Echomorph plays whatever move YOU played last turn. Turn 1 it uses its own unique move (Null Pulse). After that, it mirrors you with a one-turn delay.

**What this means:**
- If you spam Gorilla Punch, it's Gorilla Punching you back every turn. You're fighting yourself.
- If you play Rocket Punch, it plays Rocket Punch. It copies YOUR tech-enhanced versions, not the base moves.
- If you play a finisher and its precondition is met on its side, the finisher WORKS. Your own finisher used against you.
- If you play a finisher and the precondition ISN'T met on its side, it fizzles (same rules as normal).

**What it does NOT copy:**
- Your passive species ability. It has its own passive (Echo), not yours.
- Mutations it hasn't seen. It only copies moves you've actually USED in this fight. Moves you never play are invisible to it.

### Unique Mechanic: ADAPTIVE RESISTANCE

Each time the Echomorph is hit by the same move twice, it gains +50% damage reduction against that move. Third time, +75%. Fourth time, near immunity. This stacks independently per move.

| Times hit by Move X | Damage reduction |
|---|---|
| 1st hit | 0% (full damage) |
| 2nd hit | 50% |
| 3rd hit | 75% |
| 4th+ hit | 90% |

**This is the anti-spam mechanic.** Players who found one good move and lean on it (very common in fights 1-2) get punished. The Echomorph forces you to use your ENTIRE kit. Every move in your menu needs to see play, or you run out of effective damage.

### Moveset

| Move | Cost | Base Dmg | Target | Type | Beats | Loses To | Notes |
|---|---|---|---|---|---|---|---|
| Null Pulse | 2 | 2 | Body | AREA | Evasion | Defense | Its only original move. Used Turn 1 and randomly 15% of the time. Colorless energy blast. |
| Shatter Copy | 3 | 3 | Body | POWER | Evasion | Fast | Emergency move when Echo produces a fizzle. Cracks its own membrane to release stored energy. |
| *[Your last move]* | *Your cost* | *Your base* | *Your target* | *Your type* | *Your matchups* | *Your matchups* | Copied from your previous turn. Uses your stats, not its own. |

### Boss Stats (Fight 3 Mini-Boss)

| Stat | Value |
|---|---|
| Guard | 25 |
| Composure | 25 |
| Body | 30 |
| Stamina | 12 |
| Regen | +3 |

### AI Behavior

- Turn 1: Always Null Pulse
- Turn 2+: 80% plays your last move (Echo), 15% plays Null Pulse, 5% plays Shatter Copy
- Stamina push: Mirrors your PREVIOUS stamina push too. If you pushed 4 last turn, it pushes 4 this turn. You're literally fighting your own decisions from one turn ago.
- When a move would fizzle (e.g., copied finisher without precondition), plays Shatter Copy instead

### Counterplay

The Echomorph is DESIGNED to be beaten by players who have learned to use their full kit:

1. **Vary your moves.** Never play the same move twice in a row. Adaptive Resistance only builds if you repeat. A player cycling through 4-5 different moves takes full damage every time.
2. **Bait with weak moves, hit with strong ones.** Play Sting Barrage (cheap, 1 stamina) on Turn 2 — the Echomorph copies it on Turn 3 and pushes light stamina. Meanwhile you play a heavy attack on Turn 3 and push hard. You're always one step ahead if you're thinking ahead.
3. **Use asymmetric moves.** Your finisher copied by the Echomorph might not have its precondition met. Moves that require setup (Neural Bind's info advantage, Pollen Blind's turn flip) are less effective when copied without the Squid/Bee's broader kit context.
4. **Rush it down.** The Echomorph starts with no resistance. The first hit of every move does full damage. A player who spreads damage across all their moves kills it before resistance stacks up.

### Lore

No one knows what the Echomorph actually IS. Dr. Helix has tried to dissect three of them. Each time, the tissue on the operating table restructured itself into a copy of his scalpel. Current theory: it's not a species. It's a defense mechanism — a biological mirror evolved to make predators fight themselves. It entered the tournament on its own. It has never spoken. Commander Vex lists its homeworld as "UNKNOWN" in the official bracket.

Vex's pre-fight line: "The Echomorph doesn't have techniques. It has yours. Fight it the way you've been fighting and you'll lose to yourself."

### Harvestable Mutations (Boss Loot)

The Echomorph's mutations are the most versatile in the game because they're adaptation-themed:

| Mutation | Slot | Effect |
|---|---|---|
| **Adaptive Membrane** | Torso | After being hit by the same move type twice, gain 30% resistance to that type for the rest of the fight. Defensive version of the Echomorph's own resistance. |
| **Mirror Reflex** | Arms | Once per fight, when you LOSE a technique matchup, your move still lands at 50% effectiveness instead of being canceled. |
| **Echo Core** | Head | At the start of each turn, see the opponent's selected move for 0.5 seconds before it's hidden. Glimpse of the future. Information advantage. |

These are premium because they're DEFENSIVE/UTILITY — they don't add damage, they add survivability and information. Perfect preparation for the Parasitex final.

---

## BOSS 2: HYDRAVINE — "The Regenerator"

*"You cut one head off. Two grow back."*

### Species Identity

The Hydravine is a plant-animal hybrid — a massive tangle of vine-like tendrils growing from a central root core. Its body is constantly regenerating, extending new growths, and reabsorbing damaged tissue. Fighting it is like fighting a garden that fights back. You can hack pieces off, but they grow back unless you burn the root.

### Visual Design

- **Idle:** A coiled mass of dark green-black vines with bioluminescent pink-orange veins pulsing through them. The central core glows faintly — that's the root, the only permanent part.
- **Regeneration animation:** When Regrowth triggers, new vine segments visibly sprout from damaged areas. Soft green glow expands outward. The damaged area fills back in.
- **When hurt:** Severed vine ends leak glowing sap. Dark spots where tissue was destroyed. But next turn, new growth covers the wounds.
- **Color palette:** Deep forest green, black bark textures, bioluminescent pink-orange energy veins. Alien jungle apex predator energy.

### Passive: REGROWTH

At the end of every turn, the Hydravine regenerates:
- 2 points to its most damaged resource (Guard, Composure, or Body — whichever has taken the most total damage)
- If it has mutations with HP pools, it regenerates 2 HP to the most damaged mutation instead (prioritizes mutation survival)

**What this means:**
- You can't chip the Hydravine down slowly. 2 regen per turn means attacks dealing less than 2 effective damage per turn are literally doing nothing. The Hydravine outheals chip.
- The regen targets the MOST DAMAGED resource. If you spread damage across Guard and Composure evenly, the regen flip-flops between them and you make no progress on either. Focus fire is mandatory.
- Mutation regen means you can't slowly whittle down its grafted parts. You need burst — commit to destroying a mutation in 2-3 turns or it heals back.

### Unique Mechanic: VINE GRASP

Every 3 turns, the Hydravine uses a free action (no turn cost, no stamina cost) that wraps vines around the player. Vine Grasp applies a 2-turn debuff:

**ENTANGLED:** Your move costs are +1 stamina for 2 turns. Evasion-type moves are disabled (you can't dodge when you're wrapped in vines).

This fires automatically at the end of Turn 3, Turn 6, Turn 9, etc. The player knows it's coming — they can see the vine timer on the Hydravine's HUD. But they can't prevent it.

**Counterplay for Vine Grasp:**
- GRAB-type moves break Entangle early (you grab the vines and tear them off — costs your turn but clears the debuff)
- High-stamina players can power through the +1 cost increase
- Bee Swarm and Squid suffer most (cheap moves become less cheap, evasion disabled). Gorilla and Turtle handle it better (power and defense don't need evasion).

### Moveset

| Move | Cost | Base Dmg | Target | Type | Beats | Loses To | Notes |
|---|---|---|---|---|---|---|---|
| Vine Lash | 2 | 2 | Guard | GRAB | Defense | Fast | Long-range vine whip. Pulls through defenses. |
| Thorn Burst | 2 | 2 | Body | AREA | Evasion | Defense | Thorns explode outward. Can't dodge an explosion. |
| Root Drain | 3 | 2 | Body + Self | GRAB | Defense, Evasion | Power | Drains 2 Body from opponent, heals Hydravine 2 Body. Life steal. |
| Spore Cloud | 2 | 1 | Composure | PSYCHIC | Defense | Fast | Hallucinogenic spores. Composure damage + next turn opponent sees one fake move on their menu (a "ghost move" that does nothing if selected). |
| Bloom Crush | 5 | 5 | Body (FIN) | FINISHER | Power, Defense | Fast, Evasion | FINISHER. Requires opponent Guard broken. Massive vine eruption from below. |

### Boss Stats (Fight 3 Mini-Boss)

| Stat | Value |
|---|---|
| Guard | 25 |
| Composure | 25 |
| Body | 30 |
| Stamina | 12 |
| Regen | +3 (base) + 2 (Regrowth passive) = effectively +5 regen/turn on its most damaged resource |

### AI Behavior

- Opens with Vine Lash or Thorn Burst to establish early damage
- Uses Root Drain when below 20 Body (life steal mode)
- Uses Spore Cloud when opponent is being predictable (punish with ghost moves)
- Saves Bloom Crush for when Guard is actually broken — never wastes the finisher
- Stamina push: moderate (3-4 range). The Hydravine doesn't need to push hard because time is on its side. It wins long fights.
- After Vine Grasp triggers: immediately follows up with Root Drain or Vine Lash while opponent is entangled and can't evade

### Counterplay

The Hydravine is DESIGNED to be beaten by players who commit hard and fast:

1. **Focus fire one resource.** Pick Guard OR Composure and dump everything into it. Don't spread damage. The regen only heals the most damaged resource — if you're 15 damage into Guard and 0 into Composure, all regen goes to Guard. But if you push fast enough, you outdamage the 2/turn regen.
2. **Burst windows.** The turns BETWEEN Vine Grasps (turns 1-2, 4-5, 7-8) are your attack windows. Push maximum stamina during these turns. Pull back during Entangle turns to conserve stamina.
3. **Kill fast or die slow.** The Hydravine wins every long fight. Its regen is cumulative — over 20 turns it regenerates 40+ points of resources. Your total stamina pool doesn't keep pace. If you haven't broken a resource by turn 10, you're losing.
4. **Root Drain is the danger move.** It heals AND damages. If the Hydravine starts life-stealing, your damage advantage evaporates. Interrupt Root Drain with FAST or POWER type moves.
5. **Grab to break Entangle.** Sacrificing one turn to use a GRAB move and clear Entangle is worth it if the alternative is 2 turns of +1 costs and no evasion.

### Lore

The Hydravine is from Terraxis-IV, a jungle planet where every organism competes for light access in a canopy that extends 300 meters above the surface. The Hydravine evolved to regenerate faster than anything could eat it. It doesn't need to kill you — it just needs to outlast you. Eventually, you get tired. It never does.

Its entry into the tournament was controversial. Commander Vex initially ruled it wasn't a "fighter" — it was a plant. The Hydravine responded by wrapping its vines around his desk and squeezing until the desk cracked. Vex registered it the next day.

Dr. Helix is obsessed with it. "Do you understand what regeneration at that cellular rate means? If I could graft that onto a fighter... the implications..." He trails off and starts drawing diagrams.

Vex's pre-fight line: "The Hydravine doesn't tire. You do. This is a race, not a fight. Hit it hard and hit it fast or it'll still be standing when you can't lift your arms."

### Harvestable Mutations (Boss Loot)

| Mutation | Slot | Effect |
|---|---|---|
| **Regenerative Membrane** | Torso | Restore 1 point to your most damaged resource at the end of every turn. Passive regen. The single most valuable defensive mutation in the game. |
| **Thorn Bark** | Arms | When you successfully block or use a defensive move, attacker takes 2 Body damage. Spike Plating for non-Turtles. |
| **Root Network** | Legs | When Entangled, Grabbed, or movement-restricted, gain +2 stamina regen for the duration. Turns a debuff into fuel. |

These are premium because they're SUSTAIN — they keep you alive through the Parasitex final. Regenerative Membrane alone changes the math of the entire final fight.

---

## BOSS 3: PARASITEX — "The Thief"

*"Everything you've built? It's mine now."*

### Species Identity

The Parasitex is a parasite that has evolved to a macro scale. Normally, parasites are microscopic — this one is the size of a gorilla. Its body is a horrifying amalgamation of stolen biological material from dozens of species, held together by its own chitinous exoskeleton. It has no original anatomy except its core — everything else was taken from something else.

It is the dark mirror of the player. The player builds a Frankenstein from defeated opponents. The Parasitex IS a Frankenstein, built from fighters it defeated before the tournament even started. And now it wants YOUR parts.

### Visual Design

- **Idle:** Nightmare. A hunched, insectoid frame covered in mismatched biological parts. One arm is clearly from a gorilla-type species. One eye cluster is squid-like. Vine tendrils from a Hydravine-like organism weave through its carapace. It looks like something Dr. Helix would build if he had no ethics AND no aesthetic sense.
- **When it steals:** The stolen mutation visibly detaches from the player's sprite and attaches to the Parasitex's body. Tentacle rips off the player, lands on the Parasitex, integrates with a sickening pulse of light. The player's sprite shows a gap — a scar where the mutation was.
- **Across the fight:** The Parasitex starts ugly. It gets uglier. YOUR parts bolted onto its frame, still glowing with your tech enhancements. By mid-fight it looks like a corrupted version of your character. Your Rocket Fist on its arm. Your harvested Squid tentacle hanging off its shoulder. Your stuff. On a monster.
- **Color palette:** Sickly dark red-maroon exoskeleton, bone-white joints, whatever colors your stolen mutations have. It's visually chaotic — an intentional contrast to the clean designs of the four playable species.

### Passive: GRAFT STEAL

When the Parasitex destroys one of your mutation slots (reduces a mutation's HP to 0), it doesn't just remove the mutation. It STEALS it. The mutation transfers from your body to the Parasitex's body. The Parasitex gains that move for the rest of the fight.

**What gets stolen:**
- The mutation move itself (added to Parasitex's moveset)
- The tech enhancements on that mutation (but at 75% effectiveness — it doesn't understand YOUR tech)
- The visual — your mutation appears on the Parasitex's sprite

**What the player loses:**
- The mutation move (removed from menu)
- All tech invested in that mutation (gone)
- The mutation scar system activates (small passive bonus from the loss)

**Steal trigger:**
- The Parasitex has to actively target and destroy your mutation. It can't just auto-steal on contact.
- Each mutation has its own HP pool (8 for small, 12 for large, +5 for teched)
- The Parasitex uses targeted attacks that hit specific body slots

### Unique Mechanic: ASSIMILATE

The Parasitex has a unique Phase 2 option after winning a technique matchup. Instead of pushing maximum stamina for maximum damage, it can choose to ASSIMILATE — directing all damage from that attack to a single mutation's HP pool. Assimilate does double damage to the targeted mutation but zero damage to the player's base resources (Guard/Composure/Body).

This means the Parasitex is always choosing: hurt the player, or hunt the player's parts.

**Assimilate targeting priority (AI):**
1. Mutation with tech enhancements (most valuable to steal)
2. Mutation with lowest remaining HP (easiest to kill and steal)
3. Most recently grafted mutation (freshest tissue = easiest to detach)

**Player-side communication:**
- When the Parasitex wins a matchup, the screen shows: "ASSIMILATE?" with the targeted mutation highlighted on the player's body
- The player sees exactly which part is being hunted BEFORE damage resolves
- This creates the desperation: "It's going after my Rocket Fist. I CANNOT let it win the next matchup."

### Moveset

The Parasitex starts with 4 base moves. It gains additional moves from stolen mutations, potentially reaching 6-8 moves by late fight.

| Move | Cost | Base Dmg | Target | Type | Beats | Loses To | Notes |
|---|---|---|---|---|---|---|---|
| Parasite Lunge | 2 | 2 | Guard | FAST | Power, Finishers | Area | Quick strike. Sets up Assimilate opportunity. |
| Chitin Rend | 3 | 3 | Body | POWER | Evasion | Fast | Heavy slash with stolen claws. High base damage for direct Body pressure. |
| Nerve Tap | 2 | 2 | Composure | PSYCHIC | Defense | Fast | Stolen neural tissue lets it read your pain signals. |
| Cocoon | 2 | 0 | Self (defense) | DEFENSE | Fast | Grab, Psychic | Wraps in chitinous shell. Blocks damage. Regenerates 2 Body while cocooned. |
| Parasitic Bloom | 6 | 6 | Body (FIN) | FINISHER | Power, Defense, Grab | Fast, Evasion | FINISHER. Requires: has stolen at least 1 mutation from the player. Unleashes all stolen biological material in one eruption. Damage = base 6 + 2 per stolen mutation. |
| *[Stolen Move 1]* | *Original cost* | *Original base × 0.75* | *Original* | *Original* | *Original* | *Original* | Stolen from player. 75% damage effectiveness. |
| *[Stolen Move 2]* | *Original cost* | *Original base × 0.75* | *Original* | *Original* | *Original* | *Original* | Stolen from player. 75% damage effectiveness. |

### Boss Stats (Fight 4 Final Boss)

| Stat | Value |
|---|---|
| Guard | 30 |
| Composure | 25 |
| Body | 35 |
| Stamina | 12 |
| Regen | +4 |

The Parasitex is the tankiest thing in the game. 35 Body means it takes sustained commitment to kill. Combined with Cocoon healing and potential life-steal from stolen mutations, the fight is an endurance test.

### AI Behavior

**Phase 1 (Turns 1-5): HUNTING**
- Prioritizes winning technique matchups over damage
- Uses Parasite Lunge (FAST, beats Power and Finishers) to win matchups
- When it wins a matchup: always Assimilates, targeting the player's most valuable mutation
- Goal: steal 1-2 mutations in the opening before the player adapts

**Phase 2 (Turns 6-12): BUILDING**
- Now using its stolen moves alongside base kit
- Switches between Assimilate (hunting remaining mutations) and normal damage (pressuring Body)
- Uses Chitin Rend and stolen Power moves for direct Body damage
- Uses Nerve Tap to chip Composure if it has no more mutations to steal

**Phase 3 (Turns 13+): FINISHING**
- If it has stolen at least 1 mutation: begins setting up Parasitic Bloom
- Parasitic Bloom with 2 stolen mutations = 10 base damage. With heavy stamina push that's potentially lethal.
- If it hasn't stolen any mutations: plays as a stat-stick bruiser with its elevated stats. Still dangerous but lacks the explosive finisher.

**Stamina push patterns:**
- Assimilate turns: moderate push (3-4). Enough to damage the mutation, but saving stamina for follow-up.
- Damage turns: heavy push (5-6). Going for the kill.
- Cocoon turns: minimum push (2). Defensive heal.
- Finisher: all-in (8-10). This is the kill shot.

### Counterplay

The Parasitex is DESIGNED to force the hardest decision in the game: protect your build or sacrifice it for the win.

1. **Race it.** Ignore mutation protection. Go all-in on Body damage from turn 1. The Parasitex has 35 Body but if you commit maximum stamina every turn, you can kill it before it steals more than one mutation. Aggressive players who built burst-damage loadouts thrive here.

2. **Sacrifice strategically.** The galaxy-brain play: LET it steal a weak mutation early. The Parasitex wastes Assimilate turns on a mutation that costs you nothing important, and you use those turns to deal massive damage to its exposed resources. Deliberately entering the fight with one "bait" mutation in a disposable slot is advanced play.

3. **Win every matchup.** If the Parasitex never wins a technique matchup, it can never Assimilate. A player who reads the AI perfectly — countering Parasite Lunge with Area moves, countering Chitin Rend with Fast moves — never gives it a steal window. This is the high-skill-ceiling path.

4. **Break its Composure.** Nerve Tap goes both ways. If YOU have Composure attacks (Squid moves, harvested Mind Spike, etc.), breaking the Parasitex's Composure makes its stolen moves less effective (Composure break debuff affects setup and info moves). A Squid player's Synapse Swap is devastating here — scramble the Parasitex's growing moveset and its stolen moves become liabilities.

5. **Finisher-proof yourself.** Parasitic Bloom requires at least 1 stolen mutation. If you can keep the Parasitex from stealing ANYTHING, it loses access to its finisher entirely. A Parasitex without Parasitic Bloom is a stat-stick with no closer. Still tough, but no explosive kill threat.

6. **The Echomorph mutations counter the Parasitex.** Adaptive Membrane (30% resistance after 2 hits of same type) protects mutations from Assimilate burst. Mirror Reflex (one free half-damage on matchup loss) gives you a safety net against surprise Assimilate triggers. This is why the Fight 3 mini-boss loot feeds directly into Fight 4 preparation.

### Lore

Nobody knows the Parasitex's real name because it doesn't have one. It doesn't have a species. It doesn't have a homeworld. It's a THING that arrived at Axis-9 twelve years ago, killed a fighter in the lower decks, and grafted the dead fighter's arms onto its own body. Then it killed another fighter. And another.

Commander Vex wanted it banned. The Galactic Combat Commission overruled him. The crowds loved it. Ratings tripled the first time the Parasitex ripped a mutation off a fighter mid-round on live broadcast. The Commission called it "unprecedented competitive entertainment." Vex called it "a war crime with a fight record."

Dr. Helix has a complicated relationship with the Parasitex. It does what he does — grafting biological material from one species onto another. But Helix does it with precision, knowledge, and (debatable) consent. The Parasitex does it with violence. Helix considers it "an insult to the craft." He has also requested tissue samples on fourteen separate occasions.

The Parasitex has won the last three tournaments. No fighter has beaten it. Its mutation collection includes pieces from over forty species. Most of them are barely functional — the Parasitex hoards biological material the way a crow collects shiny objects. But the ones that work, work devastatingly.

It communicates through pheromones that other species interpret as dread.

**Vex's pre-fight line:** "That's the Parasitex. It takes what you've built and uses it against you. Everything you earned in this tournament — your mutations, your tech, your confidence — it wants all of it. Protect your parts or kill it fast. There's no third option."

**Helix's pre-fight line:** "I hate that thing. It has no technique, no finesse, no ARTISTRY. It just... takes. Like a toddler in a surgery bay. But I won't lie to you — if you bring me a piece of it, I could do extraordinary things. Unprecedented things. Win, and bring me something."

**Ark's pre-fight line:** "Customer. A reminder. Your enhancements are attached to your mutations. If the Parasitex steals them, my work goes with it. I offer no warranties, but I'll note that I DO offer insurance. ...I'm joking. I don't offer insurance. Protect your investments."

### Harvestable Mutations (Boss Loot — Post-Game / Run Reward)

Since the Parasitex is the final fight, harvesting happens on the victory screen. These mutations carry to the meta-progression / codex for future runs.

| Mutation | Slot | Effect |
|---|---|---|
| **Parasitic Link** | Head | When you deal Body damage, heal 1 Body. Life steal. The most powerful sustain mutation in the game. |
| **Chitin Exoframe** | Torso | All incoming damage reduced by 1 (minimum 1). Flat damage reduction that makes chip strategies useless against you. |
| **Assimilation Tendril** | Arms | Once per fight, when you destroy an opponent's mutation, gain a temporary copy of that move for 3 turns. The player becomes the Parasitex. |

These are the chase items. The reason players run the demo again. "I need to beat the Parasitex to get Parasitic Link so I can steamroll my next run." That's the itch.

---

## Boss Encounter Summary

### Echomorph (Fight 3 Mini-Boss)

| Category | Detail |
|---|---|
| **Fantasy** | Fighting yourself. Your own moves turned against you. |
| **Core question** | Can you use your ENTIRE kit, or are you a one-trick? |
| **Player archetype it punishes** | Spammers who found one good move and repeat it |
| **Player archetype it rewards** | Adaptive players who vary their approach every turn |
| **The moment** | When the Echomorph copies your Rocket Punch and hits you with YOUR signature move. The "oh shit, it's learning" realization. |
| **Best loot** | Echo Core (see opponent's move briefly) — sets up the Parasitex fight |

### Hydravine (Fight 3 Mini-Boss)

| Category | Detail |
|---|---|
| **Fantasy** | Racing against a clock. The vine wall is growing back faster than you can cut it. |
| **Core question** | Can you commit hard enough to outdamage regen, or will you gas out? |
| **Player archetype it punishes** | Cautious players who chip slowly and play safe |
| **Player archetype it rewards** | Aggressive players who commit maximum stamina and focus fire |
| **The moment** | When you see a resource you chipped to 5 heal back to 9 at end of turn. The "I'm not making progress" panic. |
| **Best loot** | Regenerative Membrane (passive regen) — the ultimate survival tool for the Parasitex fight |

### Parasitex (Fight 4 Final Boss — ALWAYS)

| Category | Detail |
|---|---|
| **Fantasy** | Everything you built is being torn apart. The monster is wearing your face. |
| **Core question** | Is your build good enough to survive losing parts of it? |
| **Player archetype it punishes** | Builders who invested everything into one perfect mutation (sunk cost devastation) |
| **Player archetype it rewards** | Players who built redundancy, who can fight with AND without their mutations |
| **The moment** | When the Parasitex tears off your Rocket Fist — the thing you've had since Fight 1, the thing that defines your character — and uses it against you next turn. The "that's MY arm" moment. That's the clip. That's the stream highlight. That's the Steam review that says "I've never been so angry at a video game boss." |
| **Best loot** | Assimilation Tendril (steal opponent mutations yourself) — the ultimate power fantasy reversal |

---

## How Bosses Feed the Pokémon Itch

**First run:** Player enters Fight 3 blind. Gets destroyed by the Echomorph because they've been spamming Gorilla Punch. Or gets outlasted by the Hydravine because they played too cautiously. Death teaches them: "I need to adapt."

**Second run:** Player adjusts. Beats the Fight 3 mini-boss. Harvests a boss mutation. Walks into the Parasitex fight with premium loot. Gets their Rocket Fist stolen in turn 4. Loses.

**Third run:** Player plans the entire run around the Parasitex. "I'm keeping one bait mutation in my Arms slot. My real build is in my Torso and Legs. When it steals the bait, I go all-in." They win. They get Parasitic Link. They feel like a genius.

**Fourth run:** "What if I played as Psycho Squid and Synapse Swapped the Parasitex's stolen moves? It wouldn't even know which of MY moves it's using..."

That's the itch. Run after run, each one informed by the last, each one building toward mastery of the final fight. The Parasitex IS the game. Everything else is preparation.
