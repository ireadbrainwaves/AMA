# AMA: Mutation Combat System — How Mutations Live and Die in Combat

**Four slots. Four resources. Armor that shatters.**

---

## The Core Principle

Mutations aren't stat buffs. They're BODY PARTS with their own health pools that absorb damage, provide moves, and shatter dramatically when destroyed. A fight between two mutated fighters is a war of disassembly — you're not just draining health bars, you're tearing your opponent apart piece by piece while protecting your own grafts.

---

## Slot-to-Resource Map

Each mutation slot protects a specific base resource. Damage aimed at that resource hits the mutation FIRST. The mutation acts as armor — it absorbs damage until its HP hits zero, then it shatters and the resource underneath takes the hit.

| Slot | Protects | Fantasy | What Losing It Means |
|---|---|---|---|
| **Head** | Composure | Your mind, your focus, your ability to plan | Mental collapse. Info/setup moves cost double. Vulnerable to Psychic Crush. |
| **Arms** | Guard | Your physical defense, your ability to block | Defenseless. Can't block or brace. Finishers that need broken Guard are live. |
| **Torso** | Body | Your health, your ability to take hits | Bleeding out. Direct Body damage = closest to death. |
| **Legs** | Stamina | Your fuel, your ability to act | Crippled. Can't afford expensive moves. Regen drops. Functionally paralyzed. |

### Why This Map Works

- **Head → Composure** is intuitive. Your brain controls your mental state. A neural implant in the head slot protects your Composure. Destroying someone's head mutation scrambles their thinking.
- **Arms → Guard** is intuitive. Your arms block attacks. An arm mutation (chitin gauntlets, tentacle grapples) adds Guard protection. Destroying it strips their ability to defend.
- **Torso → Body** is intuitive. Your torso is your vital center. Torso armor absorbs damage that would otherwise hit your Body. Destroying it exposes your vitals.
- **Legs → Stamina** is the sneaky-brutal one. Your legs are your base, your engine, your ability to generate force. A leg mutation (thruster legs, root anchors) gives you more gas. Destroying it drains your stamina — you can't move, can't generate power, can't afford your best moves. You're alive but crawling.

---

## How Mutations Absorb Damage

### The Damage Flow

```
ATTACK
  ↓
Is target resource protected by a mutation?
  ├── YES → Damage hits mutation HP first
  │         ├── Mutation survives → Resource takes 0 damage
  │         └── Mutation dies → ARMOR BREAK
  │                              → Overkill damage passes through to resource
  │                              → Shatter animation plays
  │                              → Move from that mutation removed from menu
  └── NO → Damage hits resource directly (no mutation = no shield)
```

### Armor Break

When a mutation's HP hits 0, ALL remaining overkill damage passes through to the protected resource. This is a BURST — not chip damage, not gradual. It's the wall crumbling all at once.

**Example:**
- Opponent has a Torso mutation with 4 HP remaining. Torso protects Body.
- Player lands Gorilla Punch with 7 total damage.
- Mutation absorbs 4, dies. Remaining 3 damage hits Body directly.
- If that 3 damage drops Body to 0, the mutation shatter IS the killing blow.

**Example (overkill finisher):**
- Opponent has an Arms mutation with 6 HP. Arms protects Guard.
- Player lands a fully-charged attack dealing 12 damage.
- Mutation absorbs 6, shatters. 6 overkill damage floods into Guard.
- Guard was at 8, now at 2. Nearly broken from a single hit that went through armor.
- The "armor break into Guard collapse" is a two-stage destruction that feels devastating.

### The Shatter Moment

When a mutation breaks, the game plays a full visual/audio sequence:

1. **Crack** (0.1s) — Fracture lines appear across the mutation on the sprite
2. **Shatter** (0.3s) — Mutation fragments fly off the character sprite. Sparks, dust, biological debris depending on the mutation type (metal fragments for tech, chitin shards for armor, tentacle chunks for bio)
3. **Exposed** (0.2s) — The sprite shows a visible gap/scar where the mutation was. The protected resource bar FLASHES red as overkill damage hits
4. **HUD update** (0.1s) — The mutation's move grays out and slides off the move menu. The slot shows "DESTROYED" with a scar icon
5. **Momentum shift** — Camera/screen subtle shake. The fight just changed.

Total animation: ~0.7 seconds. Long enough to feel significant, short enough to not interrupt flow.

---

## Move Types and What They Target

Move type determines what part of the opponent's body you're attacking. This isn't a player choice per se — it's baked into the move itself. When you pick Gorilla Punch (POWER type), you're hitting physical structure. When you pick Mind Spike (PSYCHIC type), you're hitting the mind directly.

### Targeting Rules by Move Type

| Move Type | What It Hits | Mutation Interaction | Strategic Use |
|---|---|---|---|
| **POWER** | Guard (via Arms mutation if present) | Absorbed by Arms mutation first | Break their physical defense. Strip their arm grafts. |
| **FAST** | Body (via Torso mutation if present) | Absorbed by Torso mutation first | Chip health through armor. Speed attacks find weak spots in torso plating. |
| **GRAB** | Guard (via Arms mutation if present) | Absorbed by Arms mutation first, BUT grabs deal +50% to mutation HP (ripping) | Tear grafts off physically. Grabs are the best mutation destroyers. |
| **PSYCHIC** | Composure (bypasses physical mutations) | IGNORES Arms/Torso/Legs mutations. Only blocked by Head mutations. | Bypass all physical armor. The anti-tank option. Only Head mutations protect against this. |
| **AREA** | Body (via Torso mutation if present) + splash 1 to adjacent slot | Primary hit absorbed by Torso, splash hits a random other mutation for 1 damage | Wide damage. Chips multiple mutations at once. Good for softening armor for follow-up. |
| **DEFENSE** | Self (no target) | N/A — defensive moves protect your own mutations | Blocks incoming damage. Spike Shell reflects damage back. |
| **EVASION** | Self (no target) | N/A — evasive moves dodge entirely | Avoid all damage including mutation damage. |
| **FINISHER** | Body (direct, bypasses all mutations) | Finishers go THROUGH mutations to hit Body directly | The kill shot. Mutations can't save you from a finisher. But finishers have preconditions. |

### Key Interactions

**Grabs are mutation killers.** Iron Grip, Vine Lash, Neural Bind — these physically seize the opponent's body parts. The +50% damage to mutation HP means a Grab is the fastest way to destroy a graft. A Gorilla who lands Iron Grip on a Squid's tentacle arm is literally ripping it off.

**Psychic bypasses physical armor.** A fighter stacked with Torso chitin and Arm plating feels invincible against physical attacks — but a Squid's Mind Spike goes straight through all of it to hit Composure. Only Head mutations (neural shields, psionic dampeners) block psychic attacks. This is WHY the type chart has Squid beating Turtle — the shell is useless against thoughts.

**Finishers bypass everything.** Primal Rage, Psychic Crush, Death Cloud, Tidal Crush — these hit Body directly. No mutation absorbs finisher damage. The finisher is the "I'm done playing with your armor" move. But it requires a precondition (broken Guard, broken Composure, etc.), which means you still have to crack through SOMETHING first.

**Area attacks chip multiple mutations.** Swarm Pressure, Ground Pound, Thorn Burst — these hit the primary target (Torso/Body) but splash 1 damage to a random adjacent mutation. Over several turns, Area attacks soften ALL the opponent's grafts, setting up focused follow-up attacks to pop the weakened one.

---

## Mutation HP Pools

### Base HP by Mutation Category

| Category | Base HP | Examples |
|---|---|---|
| Small (passive/utility) | 8 HP | Sensory enhancements, neural implants, reflex boosters |
| Large (combat/structural) | 12 HP | Chitin armor, tentacle arms, thruster legs, shell plating |
| Boss mutations | 15 HP | Adaptive Membrane, Regenerative Membrane, Parasitic Link |

### Tech Enhancement HP Bonus

Tech enhancements from Ark add durability to the mutation they're attached to:

| Enhancement | HP Bonus | Notes |
|---|---|---|
| Any offensive tech (Plasma Coating, Venom Injector) | +3 HP | Minor reinforcement from the tech housing |
| Titanium Reinforcement (defensive tech) | +5 HP | Specifically designed to harden the graft |
| Auto-Repair Nanites | +3 HP + regenerates 1 HP/turn | Self-healing armor. Premium defensive investment. |

A fully teched large mutation: 12 base + 5 (Titanium) + 3 (Plasma Coating) = **20 HP**. That's a serious investment to crack. But remember — all that tech is LOST if the mutation dies. And lost again if the Parasitex steals it.

### Mutation Type Weaknesses

Each mutation has a biological type that determines which attack types deal bonus damage to it:

| Mutation Origin | Weak To | Resistant To | Why |
|---|---|---|---|
| **Gorilla grafts** (muscle/bone) | FAST (+50% dmg to mutation) | POWER (-25%) | Dense muscle is hard to punch through, but fast strikes find gaps in the bulk |
| **Squid grafts** (neural/tentacle) | POWER (+50%) | PSYCHIC (-25%) | Soft tissue shreds under heavy hits, but psychic energy is familiar territory |
| **Bee grafts** (swarm/chitin) | AREA (+50%) | FAST (-25%) | Area attacks scatter the swarm nodes, but individual fast strikes miss the dispersed targets |
| **Turtle grafts** (shell/armor) | GRAB (+50%) | POWER (-25%) | Grabs find purchase on shell edges and rip, but blunt force bounces off |
| **Echomorph grafts** (adaptive) | Consistent damage (no weakness) | Repeated same-type (-25% per hit) | Adapts to whatever hits it, but doesn't resist the first hit of anything |
| **Hydravine grafts** (vine/regen) | FAST (+50%) | Sustained low damage (heals through chip) | Fast slashes cut faster than vines regrow, but slow chip gets outhealed |
| **Parasitex grafts** (chitin/stolen) | PSYCHIC (+50%) | GRAB (-25%) | The parasite's nervous system is its weakness — it can't handle mental attacks on stolen tissue |

### What This Means Strategically

When the player sees the Fight 3 opponent on the bracket — a Bee Swarm with a Gorilla arm mutation and a Turtle torso mutation — they can plan:

- "The Gorilla arm mutation is weak to FAST. My Sting Barrage deals +50% to it. I can shred that arm in 2-3 hits."
- "The Turtle torso mutation is weak to GRAB. I don't have a grab move... but if I harvest a grab mutation from Fight 2, I can crack that shell."
- "Their head slot is empty — no Composure protection. If I have Psychic attacks, I go straight for the mind."

This is Pokémon team preview. You see the opponent, you identify weaknesses, you plan your approach. The bracket display IS the team preview screen.

---

## How Mutations Interact with Resources

### Type A: Shield Mutations (Separate HP Pool)

The mutation has its own HP bar. Damage aimed at the protected resource hits the mutation instead. When the mutation dies, overkill flows through.

**Examples:**
- Chitin Plating (Torso): 12 HP shield protecting Body
- Neural Dampener (Head): 8 HP shield protecting Composure
- Thruster Legs (Legs): 10 HP shield protecting Stamina

### Type B: Pool Expansion Mutations (Add to Resource Max)

The mutation directly increases the maximum of the protected resource. If destroyed, the resource max drops back down (and current value is capped at new max).

**Examples:**
- Bone Density Graft (Torso): +5 Body max (25 → 30)
- Reinforced Shell (Arms): +5 Guard max (20 → 25)
- Adrenaline Glands (Legs): +3 Stamina max (10 → 13)

**On destruction:** Max drops. If current resource exceeds new max, it's capped. So if Body is at 28/30 and the +5 mutation breaks, Body drops to 25/25. No burst damage, but you just lost 3 effective health permanently.

### Type C: Reduction Mutations (Passive Damage Reduction)

The mutation passively reduces incoming damage to the protected resource by a flat amount or percentage. The mutation itself has HP and can be destroyed by targeting it specifically.

**Examples:**
- Chitin Exoframe (Parasitex loot): All incoming damage reduced by 1
- Thick Hide (Gorilla natural): Reduce Body damage by 20%
- Psionic Shield (Squid mutation): Reduce Composure damage by 1

**On destruction:** The damage reduction disappears AND armor break applies. Double punishment.

---

## The Fight Arc with Mutations

### Early Fight (Turns 1-5): SCOUTING
- Both fighters have full mutations. Maximum move options. Maximum armor.
- Players identify opponent mutations and plan targeting.
- Light probing — testing which mutations are weak to your attacks.
- "Their arm mutation took double damage from my fast attack — it's a Gorilla graft. I can focus that."

### Mid Fight (Turns 6-12): DISMANTLING
- First mutations start breaking. Armor break bursts shift the resource balance.
- Losing a mutation is a momentum swing — fewer moves, exposed resource, but the fight is still winnable.
- Strategic decision: do I protect MY mutations or race to destroy THEIRS?
- Scar bonuses from lost mutations provide small consolation.

### Late Fight (Turns 13-20): STRIPPED DOWN
- Most mutations destroyed on both sides. Fighters are back to base kits + whatever survived.
- Resources are cracked. Finisher preconditions might be met.
- This is the "both Pokémon at red HP" moment. Every move matters. One mistake ends it.
- The fight that started with 8+ moves per fighter is now 4-5. Simpler, more desperate, faster.

### The Kill Shot
- Finishers bypass mutations entirely — they hit Body direct.
- But the precondition (broken Guard, broken Composure, depleted Stamina) had to be achieved through mutation destruction first.
- The sequence is: destroy arm mutation (armor break damages Guard) → Guard breaks → finisher is live → land finisher → Body drops → KO.
- That's a 3-stage kill sequence: crack the armor, break the resource, land the finisher. Each stage is its own moment.

---

## How This Connects to the Rest of the System

### Harvesting
- Mutations you destroyed are harder for Helix to salvage (they're wrecked)
- Mutations you left intact are pristine — better harvest options
- This creates the combat-style-affects-harvest loop: do you target their best mutation to remove their strongest move (smart combat) or avoid it to harvest it later (smart building)?

### Tech Investment
- Tech is attached to mutations. Tech makes mutations tougher (more HP).
- But tougher mutations that get stolen by the Parasitex are MORE dangerous — it gets your tech at 75% effectiveness.
- Over-investing in one mutation creates a high-value target for the Parasitex.

### The Parasitex
- Graft Steal triggers on mutation death. The Parasitex doesn't just break your mutation — it takes it.
- Armor break still happens (overkill to your resource), AND the Parasitex gains the move.
- A fully-teched Rocket Fist mutation getting stolen is: lose the move, lose all tech credits invested, take armor break damage to Guard, AND the Parasitex now has Rocket Punch at 75%. Devastating.

### The Bracket
- Opponent mutations visible on the bracket = you can plan which attack types to bring.
- "Fight 3 has a Turtle torso mutation. I need GRAB moves. Fight 2 has a Gorilla with a grab... if I harvest that grab move, I can use it to crack Fight 3's shell."
- The bracket is a puzzle. Mutation targeting knowledge is how you solve it.

---

## Summary: The Mutation Combat Loop

1. **SEE** their mutations on the bracket (desire + planning)
2. **FIGHT** them — your move type determines what you target
3. **CRACK** their mutations — armor break burst damages the resource underneath
4. **BREAK** the resource — unlock finisher preconditions
5. **FINISH** — bypass all remaining armor, hit Body direct, KO
6. **HARVEST** — what you didn't destroy is what Helix can salvage
7. **GRAFT** — the mutation you took is now YOUR armor for the next fight
8. **REPEAT** — walk to the bracket, see the next opponent, plan again

Each fight strips both fighters down to their bones. Each harvest builds them back up. Each fight after that strips them down again. The player's body is constantly being destroyed and rebuilt across the run. By Fight 4, they're a Frankenstein who's been broken and reassembled three times — and the Parasitex wants to break them one more time.
